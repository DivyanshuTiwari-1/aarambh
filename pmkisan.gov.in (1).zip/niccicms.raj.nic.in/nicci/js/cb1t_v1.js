var _0xb72139 = _0x4a3a;
(function(_0x54f66f, _0x371122) {
    var _0x51d95b = _0x4a3a,
        _0x4147c3 = _0x54f66f();
    while (!![]) {
        try {
            var _0x159702 = -parseInt(_0x51d95b(0x233)) / 0x1 + parseInt(_0x51d95b(0x2d6)) / 0x2 * (-parseInt(_0x51d95b(0x316)) / 0x3) + -parseInt(_0x51d95b(0x302)) / 0x4 + parseInt(_0x51d95b(0x279)) / 0x5 + parseInt(_0x51d95b(0x272)) / 0x6 + parseInt(_0x51d95b(0x252)) / 0x7 + parseInt(_0x51d95b(0x22c)) / 0x8;
            if (_0x159702 === _0x371122) break;
            else _0x4147c3['push'](_0x4147c3['shift']());
        } catch (_0x3dc464) {
            _0x4147c3['push'](_0x4147c3['shift']());
        }
    }
}(_0x1ae3, 0xb22ac));
var msg, invalidSearchCount = 0x0,
    isVoicemute = ![];
let $userName = '';
var lang_Hindi = ![],
    starRating = '0',
    date = new Date(),
    noteContent = '',
    specialKeys = new Array();
specialKeys['push'](0x8), specialKeys[_0xb72139(0x320)](0x9), specialKeys[_0xb72139(0x320)](0xd), specialKeys[_0xb72139(0x320)](0x2e), specialKeys['push'](0x24), specialKeys['push'](0x23), specialKeys[_0xb72139(0x320)](0x25), specialKeys[_0xb72139(0x320)](0x27);
var recognition;

function setLanguageMode() {
    var _0x4f57ff = _0xb72139;
    if ($(_0x4f57ff(0x1e0))[_0x4f57ff(0x2ca)] > 0x0) {
        disabled(0xbb8), lang_Hindi = $('#ctl01_chkLang')['prop'](_0x4f57ff(0x2c9));
        if (getBrowserType() == _0x4f57ff(0x232) && lang_Hindi) $(_0x4f57ff(0x306))[_0x4f57ff(0x290)](0x3e8);
        else $(_0x4f57ff(0x306))[_0x4f57ff(0x1f7)](0x1f4);
        !lang_Hindi ? ($(_0x4f57ff(0x29a))[_0x4f57ff(0x261)](_0x4f57ff(0x1bb), _0x4f57ff(0x308)), $(_0x4f57ff(0x1e0))[_0x4f57ff(0x261)](_0x4f57ff(0x1db), _0x4f57ff(0x27d)), recognition['lang'] = _0x4f57ff(0x253)) : ($(_0x4f57ff(0x29a))[_0x4f57ff(0x261)](_0x4f57ff(0x1bb), _0x4f57ff(0x2a0)), $('#ctl01_chkLang')['attr'](_0x4f57ff(0x1db), 'Choose\x20English'), recognition['lang'] = _0x4f57ff(0x20a));
        $(_0x4f57ff(0x1d2))['empty'](), $(_0x4f57ff(0x29a))['empty'](), noteContent = '', window[_0x4f57ff(0x309)][_0x4f57ff(0x2f5)]();
        if ($('#start-chat')[_0x4f57ff(0x28a)]()[_0x4f57ff(0x2b1)]() == _0x4f57ff(0x20c)) {
            nicci_tracer($(_0x4f57ff(0x1f2))[_0x4f57ff(0x203)](), $userName), $(_0x4f57ff(0x2f4))[_0x4f57ff(0x26c)]();
            var _0x992d32 = '';
            setSearchSlider(lang_Hindi);
            if (!lang_Hindi) _0x992d32 = [_greetMsg + '\x20' + $userName, 'This\x20is\x20NICCI,\x20your\x20digital\x20assistant\x20for\x20any\x20query\x20related\x20to\x20' + _portalName, _0x4f57ff(0x1fb)];
            else _0x992d32 = [_greetMsgH + '\x20' + $userName, _0x4f57ff(0x31f) + _portalName + _0x4f57ff(0x282)];
            if (_isTagSuggestionOn[_0x4f57ff(0x1ec)]() == _0x4f57ff(0x26e)) setTimeout(function() {
                var _0x289ab9 = _0x4f57ff;
                document['getElementById'](_0x289ab9(0x283))[_0x289ab9(0x295)] = !![], getTags(0x0);
            }, 0x7d0 * (_0x992d32['length'] - 0x1));
            else setTimeout(function() {
                var _0x2d9c41 = _0x4f57ff;
                $(_0x2d9c41(0x2f4))[_0x2d9c41(0x2eb)](0x1f4), document[_0x2d9c41(0x207)](_0x2d9c41(0x283))[_0x2d9c41(0x295)] = !![];
            }, 0x7d0 * (_0x992d32[_0x4f57ff(0x2ca)] - 0x1));
            if (typeof _0x992d32 === 'string') postBotReply(_0x992d32);
            else
                for (var _0x25c588 = 0x0; _0x25c588 < _0x992d32[_0x4f57ff(0x2ca)]; _0x25c588++) {
                    (function(_0x4eff33) {
                        var _0x407b29 = 0x7d0 * _0x4eff33;
                        setTimeout(function() {
                            var _0x2bcf97 = _0x4a3a;
                            postBotReply(_0x992d32[_0x4eff33]), $('#chatAudio')[0x0][_0x2bcf97(0x25e)]();
                        }, _0x407b29);
                    }(_0x25c588));
                }
        }
    }
}

function disabled(_0x197efa) {
    var _0x36f68e = _0xb72139;
    $(_0x36f68e(0x26b))[_0x36f68e(0x1f6)](_0x36f68e(0x1da)), $(_0x36f68e(0x28e))['removeClass']('fa-info-circle'), $(_0x36f68e(0x1e0))[_0x36f68e(0x1c4)](_0x36f68e(0x1be), !![]), setTimeout(function() {
        var _0x20381f = _0x36f68e;
        $(_0x20381f(0x1e0))[_0x20381f(0x1c4)](_0x20381f(0x1be), ![]), $(_0x20381f(0x28e))[_0x20381f(0x1f6)](_0x20381f(0x31c)), $(_0x20381f(0x26b))[_0x20381f(0x288)]('fa-refresh\x20fa-spin');
    }, _0x197efa);
}

function IsAlphaNumeric(_0x4e92ad, _0x5f8e03, _0x380c32) {
    var _0x228c1c = _0xb72139,
        _0x3abf45 = _0x4e92ad[_0x228c1c(0x266)] == 0x0 ? _0x4e92ad[_0x228c1c(0x2ff)] : _0x4e92ad[_0x228c1c(0x266)],
        _0x491721;
    return !lang_Hindi ? (_0x3abf45 == 0x20 && checkRestrictedWords(_0x5f8e03, _0x380c32), _0x491721 = _0x3abf45 == 0x8 || _0x3abf45 == 0x2e || _0x3abf45 == 0xa || _0x3abf45 == 0xd || _0x3abf45 >= 0x30 && _0x3abf45 <= 0x39 || _0x3abf45 >= 0x41 && _0x3abf45 <= 0x5a || _0x3abf45 == 0x20 || _0x3abf45 >= 0x61 && _0x3abf45 <= 0x7a || specialKeys[_0x228c1c(0x28c)](_0x4e92ad[_0x228c1c(0x266)]) != -0x1 && _0x4e92ad['charCode'] != _0x4e92ad['keyCode'] || _0x3abf45 == 0x27 || _0x3abf45 == 0x28 || _0x3abf45 == 0x29 || _0x3abf45 == 0x3f || _0x3abf45 == 0x2d || _0x3abf45 == 0x2f || _0x3abf45 == 0x2c, _0x491721 ? _0x3abf45 != 0x20 && ($('#' + _0x5f8e03)[_0x228c1c(0x305)](_0x228c1c(0x2bb))[_0x228c1c(0x280)](_0x228c1c(0x24e), _0x228c1c(0x2c7)), $('#' + _0x380c32)[_0x228c1c(0x2eb)](0x1f4)) : ($('#' + _0x5f8e03)['delay'](_0x228c1c(0x2bb))[_0x228c1c(0x280)](_0x228c1c(0x24e), '1px\x20solid\x20red'), $('#' + _0x380c32)[_0x228c1c(0x28a)](_0x228c1c(0x32a)), $('#' + _0x380c32)[_0x228c1c(0x26c)](0x1f4), setTimeout(function() {
        var _0x33ce9d = _0x228c1c;
        $(_0x33ce9d(0x29a))[_0x33ce9d(0x305)](_0x33ce9d(0x2bb))['css'](_0x33ce9d(0x24e), _0x33ce9d(0x2c7)), $('#' + _0x380c32)[_0x33ce9d(0x2eb)](0x1f4);
    }, 0xbb8))) : (_0x491721 = _0x3abf45 == 0x8 || _0x3abf45 == 0x2e || _0x3abf45 == 0xa || _0x3abf45 == 0xd || (_0x3abf45 != 0x21 || _0x3abf45 == 0x28 || _0x3abf45 == 0x29 || _0x3abf45 == 0x2d || _0x3abf45 == 0x2f || _0x3abf45 == 0x3f && _0x3abf45 != 0x23 && _0x3abf45 != 0x24 && _0x3abf45 != 0x2a && _0x3abf45 != 0x2b && _0x3abf45 != 0x2f && _0x3abf45 != 0x3c && _0x3abf45 != 0x3e && _0x3abf45 != 0x40 && _0x3abf45 != 0x5c && _0x3abf45 != 0x5e && _0x3abf45 != 0x60 && _0x3abf45 != 0x7e), _0x491721 ? _0x3abf45 != 0x20 && ($('#' + _0x5f8e03)[_0x228c1c(0x305)](_0x228c1c(0x2bb))[_0x228c1c(0x280)](_0x228c1c(0x24e), _0x228c1c(0x2c7)), $('#' + _0x380c32)['hide'](0x1f4)) : ($('#' + _0x5f8e03)[_0x228c1c(0x305)](_0x228c1c(0x2bb))[_0x228c1c(0x280)]('border', '1px\x20solid\x20red'), $('#' + _0x380c32)['html'](_0x228c1c(0x32a)), $('#' + _0x380c32)['show'](0x1f4), setTimeout(function() {
        var _0xa4afd7 = _0x228c1c;
        $('#' + _0x5f8e03)['delay']('1000')[_0xa4afd7(0x280)](_0xa4afd7(0x24e), 'none'), $('#' + _0x380c32)[_0xa4afd7(0x2eb)](0x1f4);
    }, 0xbb8))), _0x491721;
}

function IsUserNameValid(_0x11e3e6, _0x2ce504, _0x311574) {
    var _0x93f81e = _0xb72139,
        _0x4435bb = _0x11e3e6[_0x93f81e(0x266)] == 0x0 ? _0x11e3e6[_0x93f81e(0x2ff)] : _0x11e3e6[_0x93f81e(0x266)],
        _0x1baba9;
    return !lang_Hindi ? (_0x4435bb == 0x20 && checkRestrictedWords(_0x2ce504, _0x311574), _0x1baba9 = _0x4435bb == 0x8 || _0x4435bb == 0x2e || _0x4435bb == 0xa || _0x4435bb == 0xd || _0x4435bb >= 0x41 && _0x4435bb <= 0x5a || _0x4435bb == 0x20 || _0x4435bb >= 0x61 && _0x4435bb <= 0x7a || specialKeys['indexOf'](_0x11e3e6[_0x93f81e(0x266)]) != -0x1 && _0x11e3e6['charCode'] != _0x11e3e6[_0x93f81e(0x266)], _0x1baba9 ? _0x4435bb != 0x20 && ($('#' + _0x2ce504)[_0x93f81e(0x305)]('1000')[_0x93f81e(0x280)]('border', _0x93f81e(0x2c7)), $('#' + _0x311574)[_0x93f81e(0x2eb)](0x1f4)) : ($('#' + _0x2ce504)[_0x93f81e(0x305)]('1000')[_0x93f81e(0x280)](_0x93f81e(0x24e), _0x93f81e(0x2fb)), $('#' + _0x311574)[_0x93f81e(0x28a)]('<i\x20class=\x22fa\x20fa-info-circle\x22\x20aria-hidden=\x22true\x22\x20style=\x22color:\x20white;\x22></i>&nbsp;\x20Please\x20enter\x20correct\x20Name\x20!!'), $('#' + _0x311574)[_0x93f81e(0x26c)](0x1f4), setTimeout(function() {
        var _0x290b3d = _0x93f81e;
        $('#' + _0x2ce504)[_0x290b3d(0x305)](_0x290b3d(0x2bb))[_0x290b3d(0x280)]('border', _0x290b3d(0x2c7)), $('#' + _0x311574)[_0x290b3d(0x2eb)](0x1f4);
    }, 0xbb8))) : (_0x4435bb == 0x20 && checkRestrictedWords(_0x2ce504, _0x311574), _0x1baba9 = _0x4435bb == 0x8 || _0x4435bb == 0x2e || _0x4435bb == 0xa || _0x4435bb == 0xd || _0x4435bb != 0x21 && _0x4435bb != 0x23 && _0x4435bb != 0x24 && _0x4435bb != 0x2a && _0x4435bb != 0x2b && _0x4435bb != 0x2f && _0x4435bb != 0x3c && _0x4435bb != 0x3e && _0x4435bb != 0x40 && _0x4435bb != 0x5c && _0x4435bb != 0x5e && _0x4435bb != 0x60 && _0x4435bb != 0x7e, _0x1baba9 ? _0x4435bb != 0x20 && ($('#' + _0x2ce504)[_0x93f81e(0x305)]('1000')['css'](_0x93f81e(0x24e), _0x93f81e(0x2c7)), $('#' + _0x311574)['hide'](0x1f4)) : ($('#' + _0x2ce504)[_0x93f81e(0x305)]('1000')[_0x93f81e(0x280)](_0x93f81e(0x24e), _0x93f81e(0x2fb)), $('#' + _0x311574)['html'](_0x93f81e(0x2b4)), $('#' + _0x311574)[_0x93f81e(0x26c)](0x1f4), setTimeout(function() {
        var _0x2f4642 = _0x93f81e;
        $('#' + _0x2ce504)[_0x2f4642(0x305)](_0x2f4642(0x2bb))['css']('border', _0x2f4642(0x2c7)), $('#' + _0x311574)['hide'](0x1f4);
    }, 0xbb8))), _0x1baba9;
}

function $postMessage() {
    var _0x157ef0 = _0xb72139;
    if ((_searchType == '2' || _searchType == '3') && _searchSuggestion[_0x157ef0(0x2b1)]()['length'] > 0x0) $(_0x157ef0(0x23e))[_0x157ef0(0x1d6)](_0x157ef0(0x2a8));
    $(_0x157ef0(0x29a))[_0x157ef0(0x2f7)]('br')[_0x157ef0(0x1c5)]();
    let _0x3addff = $(_0x157ef0(0x29a))[_0x157ef0(0x2f8)]()[_0x157ef0(0x2b1)]();
    _0x3addff = _0x3addff[_0x157ef0(0x1cc)](/<div>/, _0x157ef0(0x2ec))[_0x157ef0(0x1cc)](/<div>/g, '')['replace'](/<\/div>/g, _0x157ef0(0x2ec))[_0x157ef0(0x1cc)](/<br>/g, '\x20')[_0x157ef0(0x1cc)](/&nbsp;/g, '\x20')['trim']();
    if (!checkInputLength(_0x3addff)) return ![];
    if (!lang_Hindi) {
        if (!(checkSymbols('message', _0x157ef0(0x1cf)) && checkRestrictedWords(_0x157ef0(0x283), _0x157ef0(0x1cf)))) return ![];
    } else {
        if (!checkRestrictedWords(_0x157ef0(0x283), 'Nicci_errorMsg')) return ![];
    }
    if ($('#message')[_0x157ef0(0x2f8)]()[_0x157ef0(0x2b1)]()['length'] > 0x0) {
        if (_0x3addff && _0x3addff[_0x157ef0(0x2ca)] > 0x3) {
            document[_0x157ef0(0x207)](_0x157ef0(0x283))['contentEditable'] = ![];
            const _0x38d418 = '<div\x20style=\x22display:flex;\x22><div><img\x20alt=\x22\x22\x20src=' + getRootWebSitePath() + ('images/userlg.png\x20style=\x22width:\x2030px;border-radius:\x2025px;max-width:\x2030px\x20!important;\x22>\x20</div><div\x20class=\x22post\x20post-user\x22>' + (_0x3addff + timeStamp()) + _0x157ef0(0x2ef));
            $(_0x157ef0(0x1d2))[_0x157ef0(0x2d5)](_0x38d418), $scrollDown(), $(_0x157ef0(0x2f4))[_0x157ef0(0x26c)](), setTimeout(function() {
                botReply(_0x3addff);
            }, 0x7d0), $(_0x157ef0(0x205))[_0x157ef0(0x28a)](''), $(_0x157ef0(0x29a))[_0x157ef0(0x1fe)](), noteContent = '';
        } else $(_0x157ef0(0x29a))['delay'](_0x157ef0(0x2bb))[_0x157ef0(0x280)](_0x157ef0(0x24e), _0x157ef0(0x2fb)), $(_0x157ef0(0x25c))['html'](_0x157ef0(0x298)), $('#Nicci_errorMsg')[_0x157ef0(0x26c)](0x1f4), setTimeout(function() {
            var _0x582251 = _0x157ef0;
            $(_0x582251(0x29a))[_0x582251(0x305)](_0x582251(0x2bb))[_0x582251(0x280)](_0x582251(0x24e), _0x582251(0x2c7)), $(_0x582251(0x25c))[_0x582251(0x2eb)](0x1f4);
        }, 0xbb8);;
    } else $(_0x157ef0(0x29a))['empty'](), noteContent = '', $('#message')[_0x157ef0(0x305)](_0x157ef0(0x2bb))['css'](_0x157ef0(0x24e), _0x157ef0(0x2fb)), $(_0x157ef0(0x25c))[_0x157ef0(0x28a)](_0x157ef0(0x298)), $(_0x157ef0(0x25c))[_0x157ef0(0x26c)](0x1f4), setTimeout(function() {
        var _0x57f2b6 = _0x157ef0;
        $(_0x57f2b6(0x29a))['delay'](_0x57f2b6(0x2bb))[_0x57f2b6(0x280)](_0x57f2b6(0x24e), _0x57f2b6(0x2c7)), $(_0x57f2b6(0x25c))['hide'](0x1f4);
    }, 0xbb8);
    return ![];
};

function firstbotReply() {
    var _0x551b2f = _0xb72139;
    disabled(0x1388), $('#ctl01_landDiv')[_0x551b2f(0x2eb)]()[_0x551b2f(0x288)](_0x551b2f(0x2a6))['addClass'](_0x551b2f(0x275))[_0x551b2f(0x290)](0x5dc), document[_0x551b2f(0x207)](_0x551b2f(0x283))[_0x551b2f(0x295)] = ![];
    if ($(_0x551b2f(0x1e0))[_0x551b2f(0x2ca)] > 0x0) lang_Hindi = $(_0x551b2f(0x1e0))[_0x551b2f(0x1c4)]('checked');
    var _0x431dba = $('#start-chat')[_0x551b2f(0x28a)]();
    setSearchSlider(lang_Hindi);
    if (_0x431dba == 'Start') {
        nicci_tracer($(_0x551b2f(0x1f2))['val'](), $userName), $(_0x551b2f(0x2f4))[_0x551b2f(0x26c)]();
        var _0x236fa2 = '';
        if (!lang_Hindi) _0x236fa2 = [_greetMsg + '\x20' + $userName, 'This\x20is\x20NICCI,\x20your\x20digital\x20assistant\x20for\x20any\x20query\x20related\x20to\x20' + _portalName, _0x551b2f(0x1fb)];
        else _0x236fa2 = [_greetMsgH + '\x20' + $userName, 'मैं\x20निक्की,\x20' + _portalName + _0x551b2f(0x282)];
        _isTagSuggestionOn['toLowerCase']() == _0x551b2f(0x26e) ? setTimeout(function() {
            var _0x145d49 = _0x551b2f;
            document['getElementById'](_0x145d49(0x283))[_0x145d49(0x295)] = !![], getTags(0x0);
        }, 0x7d0 * (_0x236fa2[_0x551b2f(0x2ca)] - 0x1)) : setTimeout(function() {
            var _0x4e9d24 = _0x551b2f;
            $(_0x4e9d24(0x2f4))[_0x4e9d24(0x2eb)](0x1f4), document[_0x4e9d24(0x207)](_0x4e9d24(0x283))[_0x4e9d24(0x295)] = !![];
        }, 0x7d0 * (_0x236fa2[_0x551b2f(0x2ca)] - 0x1));
        if (typeof _0x236fa2 === _0x551b2f(0x2da)) postBotReply(_0x236fa2);
        else
            for (var _0x3065df = 0x0; _0x3065df < _0x236fa2[_0x551b2f(0x2ca)]; _0x3065df++) {
                (function(_0x3f73b2) {
                    var _0xf58daa = 0x7d0 * _0x3f73b2;
                    setTimeout(function() {
                        var _0x28259d = _0x4a3a;
                        postBotReply(_0x236fa2[_0x3f73b2]), $('#chatAudio')[0x0][_0x28259d(0x25e)]();
                    }, _0xf58daa);
                }(_0x3065df));
            }
    }
};

function nicci_tracer(_0x548218, _0x4b5af5) {
    var _0x3d6319 = _0xb72139,
        _0x430033 = getRootWebSitePath();
    $['ajax']({
        'type': _0x3d6319(0x2ea),
        'url': _0x430033 + '/chatbotService.asmx/nicci_tracer',
        'data': _0x3d6319(0x327) + _0x548218 + '\x22,\x22name\x22:\x22' + _0x4b5af5 + '\x22}',
        'contentType': _0x3d6319(0x32e),
        'dataType': 'json',
        'async': ![],
        'success': function(_0x5e7cba) {},
        'failure': function(_0x46a0f7) {},
        'error': function(_0x374aec) {}
    });
}

function botReply(_0x35244d) {
    const _0x46e31e = generateReply(_0x35244d);
    window['speechSynthesis']['cancel'](), setTimeout(function() {
        var _0x8895a9 = _0x4a3a;
        $('#loadingimg')[_0x8895a9(0x2eb)](0x1f4), document[_0x8895a9(0x207)](_0x8895a9(0x283))[_0x8895a9(0x295)] = !![];
    }, 0x7d0 * (_0x46e31e['length'] - 0x1));
    if (typeof _0x46e31e === 'string') postBotReply(_0x46e31e);
    else
        for (var _0x2d08a2 = 0x0; _0x2d08a2 < _0x46e31e['length']; _0x2d08a2++) {
            (function(_0x4d83cb) {
                var _0x2392c9 = 0x7d0 * _0x4d83cb;
                setTimeout(function() {
                    var _0x30f53c = _0x4a3a;
                    if (_0x46e31e[_0x4d83cb]['indexOf'](':KW:') != -0x1) postBotKeywords(replaceAll(_0x46e31e[_0x4d83cb], _0x30f53c(0x25a), ''));
                    else postBotReply(_0x46e31e[_0x4d83cb]);
                    if (!isVoicemute) $('#chatAudio')[0x0][_0x30f53c(0x25e)]();
                }, _0x2392c9);
            }(_0x2d08a2));
        }
};

function generateReply(_0x4d17d7) {
    var _0x49b81c = _0xb72139;
    const _0x46f2fa = _0x4d17d7,
        _0x1f043b = _0x4d17d7[_0x49b81c(0x1ec)]();
    var _0xe15569 = getRootWebSitePath();
    date = new Date();
    let _0x132de8 = '';
    var _0x5d77a6 = new RegExp(_regx),
        _0x3a470c = new RegExp(_regx_api),
        _0x243199 = new RegExp(_regx_with_pfix);
    if (/^hi$|^hell?o|^howdy|^hoi|^hey|^ola/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_greetMsg + '\x20' + $userName, _0x49b81c(0x30e) + _portalName, 'What\x20can\x20I\x20do\x20for\x20you?'];
    else {
        if (/bye|ciao|adieu|salu/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = ['Bye,\x20Thanks\x20For\x20visiting.'];
        else {
            if (/i hate you|i hate myself/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x294)];
            else {
                if (/good morning|good evening|good afternoon|good night/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [getTimeSalutation() + '\x20' + $userName];
                else {
                    if (/please help me|help me|please suggest me|guide me|suggest me/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [$userName + _0x49b81c(0x23d)];
                    else {
                        if (/please suggest me|guide me|suggest me/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [$userName + '\x20How\x20Can\x20I\x20help\x20You'];
                        else {
                            if (/do you understand|do you understand me/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [$userName + _0x49b81c(0x23d)];
                            else {
                                if (/who are you/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = ['I\x20am\x20NICCI,\x20your\x20digital\x20assistant\x20for\x20any\x20query\x20related\x20to\x20' + _portalName];
                                else {
                                    if (/what is your name|your name|tell me your name/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = ['I\x20am\x20NICCI'];
                                    else {
                                        if (/how can you help me/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x221) + _portalName];
                                        else {
                                            if (/which languages do you speak|in which languages do you speak/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x1f1)];
                                            else {
                                                if (/how are you/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x312)];
                                                else {
                                                    if (/are you human/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x1f9)];
                                                    else {
                                                        if (/are you still there|were are you/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = ['Yes,\x20I\x20am\x20always\x20here', _0x49b81c(0x303)];
                                                        else {
                                                            if (/are you a boy or girl|you are boy or girl|are you boy or girl|are you real/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = ['I\x20am\x20AI\x20based\x20Voice\x20Enabled\x20Chatbot'];
                                                            else {
                                                                if (/tell me about yourself|your introduction|introduce yourself/ ['test'](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x2cd), _0x49b81c(0x32c), _0x49b81c(0x321) + _portalName];
                                                                else {
                                                                    if (/^thanks$|^thankyou very much|^thank|^thank you$/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x2c2) + ($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '')];
                                                                    else {
                                                                        if (/^tommarow date|^tommarow|(?=.*tommarow)(?=.*date)(?=.*what)/ ['test'](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName['length'] > 0x0 ? $userName + ',\x20' : '') + '\x20' + getTommarowDate() + _0x49b81c(0x1c8)];
                                                                        else {
                                                                            if (/^date|^today date|^current date|(?=.*today)(?=.*date)(?=.*what).*/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + '\x20' + getFullDate() + '\x20is\x20todays\x20date.'];
                                                                            else {
                                                                                if (/^today/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x29f) + getDayOfWeek()];
                                                                                else {
                                                                                    if (/^current time/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + '\x20' + date[_0x49b81c(0x2d3)]([], {
                                                                                        'hour': _0x49b81c(0x235),
                                                                                        'minute': _0x49b81c(0x235),
                                                                                        'second': _0x49b81c(0x235)
                                                                                    }) + _0x49b81c(0x2cc)];
                                                                                    else {
                                                                                        if (/^financial year|current financial year/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName['length'] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x1ef) + _financialYear];
                                                                                        else {
                                                                                            if (/^day of the week|current day name|^week day|day of week/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x29f) + getDayOfWeek()];
                                                                                            else {
                                                                                                if (/^month of the year|current month name|^month name|month of year|^month$/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [($userName['length'] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x254) + getMonthOfYear()];
                                                                                                else {
                                                                                                    if (/what is chatbot|chatbot means|chatbot kya hota hain|chatbot|what is bots/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi) _0x132de8 = [_0x49b81c(0x27c), _0x49b81c(0x329)];
                                                                                                    else {
                                                                                                        if (/please tell me my name|what is my name|tell my name|my name/ ['test'](_0x1f043b) && !lang_Hindi) _0x132de8 = ['' + ($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + '\x20is\x20your\x20name.' : _0x49b81c(0x27e))];
                                                                                                        else {
                                                                                                            if (/(?=.*hindi)((?=.*speak)|(?=.*type)|(?=.*baat)|(?=.*talk)|(?=.*language)|(?=.*bolo)|(?=.*likho)).*|(?=.*english)((?=.*mat)|(?=.*nahi)|(?=.*not))(?=.*baat).*|((?=.*not)|(?=.*nahi)|(?=.*mat))((?=.*speak)|(?=.*baat)|(?=.*chat)|(?=.*bolo))(?=.*english).*|(?=.*hindi)(?=.*bat).*|(?=.*hindi)(?=.*understand)(?=.*in).*|^hindi please/ [_0x49b81c(0x25b)](_0x1f043b) && !lang_Hindi && _isBiLang[_0x49b81c(0x1ec)]() == _0x49b81c(0x1ce)) _0x132de8 = [_0x49b81c(0x225)];
                                                                                                            else {
                                                                                                                if (/(?=.*hindi)((?=.*speak)|(?=.*type)|(?=.*baat)|(?=.*talk)|(?=.*language)|(?=.*bolo)|(?=.*likho)).*|(?=.*english)((?=.*mat)|(?=.*nahi)|(?=.*not))(?=.*baat).*|((?=.*not)|(?=.*nahi)|(?=.*mat))((?=.*speak)|(?=.*baat)|(?=.*chat)|(?=.*bolo))(?=.*english).*|(?=.*hindi)(?=.*bat).*|(?=.*hindi)(?=.*understand)(?=.*in).*|^hindi please/ ['test'](_0x1f043b) && !lang_Hindi && _isBiLang['toLowerCase']() == _0x49b81c(0x26e)) $(_0x49b81c(0x1e0))['prop'](_0x49b81c(0x2c9), _0x49b81c(0x26e)), lang_Hindi = $(_0x49b81c(0x1e0))[_0x49b81c(0x1c4)](_0x49b81c(0x2c9)), $(_0x49b81c(0x29a))[_0x49b81c(0x261)](_0x49b81c(0x1bb), 'हिन्दी\x20लिखने\x20के\x20लिए\x20Alt+Shift\x20दबाये\x20।'), $(_0x49b81c(0x2e9))[_0x49b81c(0x2f8)]('Choose\x20English'), recognition[_0x49b81c(0x1df)] = 'hi-IN', noteContent = '', window['speechSynthesis'][_0x49b81c(0x2f5)](), _0x132de8 = ['' + ($userName['length'] > 0x0 ? $userName + _0x49b81c(0x2dc) : _0x49b81c(0x1d1))];
                                                                                                                else {
                                                                                                                    if (_searchType == '1' && _regx != '' && _0x5d77a6['test'](_0x46f2fa) && !lang_Hindi) {
                                                                                                                        var _0x2c64e3 = _0x5d77a6[_0x49b81c(0x285)](_0x46f2fa),
                                                                                                                            _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','),
                                                                                                                            _0x42d590 = _0x5d77a6[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x5d77a6[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'),
                                                                                                                            _0x43d81a, _0x27dea0;
                                                                                                                        for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9[_0x49b81c(0x2ca)]; _0x3a6f03++) {
                                                                                                                            _0x4f8ea9[_0x3a6f03][_0x49b81c(0x2ca)] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1]);
                                                                                                                        }
                                                                                                                        $[_0x49b81c(0x1d3)]({
                                                                                                                            'type': _0x49b81c(0x2ea),
                                                                                                                            'url': _0xe15569 + _0x49b81c(0x31b),
                                                                                                                            'data': _0x49b81c(0x2fd) + _0x43d81a + '\x22,\x22matchedKey\x22:\x20\x22' + _0x27dea0 + '\x22,\x22authtoken\x22:\x20\x22' + $('#ctl01_hdnToken')[_0x49b81c(0x203)]() + _0x49b81c(0x29e) + lang_Hindi + '\x22,\x22searchType\x22:\x20\x22' + _searchType + '\x22}',
                                                                                                                            'contentType': _0x49b81c(0x32e),
                                                                                                                            'dataType': _0x49b81c(0x28d),
                                                                                                                            'async': ![],
                                                                                                                            'success': function(_0x3a40ed) {
                                                                                                                                var _0x331133 = _0x49b81c,
                                                                                                                                    _0x3ef238 = JSON[_0x331133(0x32d)](_0x3a40ed['d']);
                                                                                                                                if (_0x3ef238['length'] > 0x0) {
                                                                                                                                    if (_0x3ef238[0x0]['ResponseKeyWords'][_0x331133(0x2b1)]()[_0x331133(0x2ca)] > 0x0) _0x132de8 = _0x3ef238[0x0][_0x331133(0x24b)][_0x331133(0x30b)]('|'), invalidSearchCount = 0x0;
                                                                                                                                    else {
                                                                                                                                        invalidSearchCount++;
                                                                                                                                        if (invalidSearchCount == 0x2) {
                                                                                                                                            if (!lang_Hindi) _0x132de8 = [_0x331133(0x23c), _0x331133(0x1ea)];
                                                                                                                                            else _0x132de8 = [_0x331133(0x287), _0x331133(0x2f9)];
                                                                                                                                        } else {
                                                                                                                                            if (invalidSearchCount == 0x3) {
                                                                                                                                                if (!lang_Hindi) _0x132de8 = [_0x331133(0x23f), '' + _helplineMsg];
                                                                                                                                                else _0x132de8 = [_0x331133(0x26a), '' + _hhelplineMsg];
                                                                                                                                                invalidSearchCount = 0x0;
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                } else {
                                                                                                                                    invalidSearchCount++;
                                                                                                                                    if (invalidSearchCount == 0x2) {
                                                                                                                                        if (!lang_Hindi) _0x132de8 = [_0x331133(0x23c), _0x331133(0x1ea)];
                                                                                                                                        else _0x132de8 = [_0x331133(0x287), _0x331133(0x2f9)];
                                                                                                                                    } else {
                                                                                                                                        if (invalidSearchCount == 0x3) {
                                                                                                                                            if (!lang_Hindi) _0x132de8 = [_0x331133(0x23f), '' + _helplineMsg];
                                                                                                                                            else _0x132de8 = ['कभी-कभी\x20मेरे\x20पास\x20आपकी\x20द्वारा\x20पूछी\x20गयी\x20आवश्यक\x20जानकारी\x20नहीं\x20हो\x20सकती\x20है\x20।', '' + _hhelplineMsg];
                                                                                                                                            invalidSearchCount = 0x0;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            },
                                                                                                                            'failure': function(_0x217eeb) {},
                                                                                                                            'error': function(_0x832bb2) {}
                                                                                                                        });
                                                                                                                    } else {
                                                                                                                        if (_searchType == '2' && _regx_api != '' && (_0x3a470c['test'](_0x46f2fa) || _0x243199['test'](_0x46f2fa)) && !lang_Hindi) {
                                                                                                                            var _0x2c64e3, _0x4a70a4 = ![],
                                                                                                                                _0x43d81a, _0x335edd, _0x27dea0, _0x2b4943, _0x4f8ea9, _0x42d590, _0x413972, _0x4f41ec;
                                                                                                                            if (_regx_api[_0x49b81c(0x2b1)]() != _regx_with_pfix[_0x49b81c(0x2b1)]()) _0x4a70a4 = !![];
                                                                                                                            if (_0x3a470c['test'](_0x46f2fa)) _0x2c64e3 = _0x3a470c['exec'](_0x46f2fa), _0x4f8ea9 = _0x2c64e3['toString']()['split'](','), _0x42d590 = _0x3a470c['toString']()['substring'](0x1, _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|');
                                                                                                                            else _0x243199[_0x49b81c(0x25b)](_0x46f2fa) && (_0x2c64e3 = _0x243199[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','), _0x42d590 = _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x3a470c['toString']()['length'] - 0x1)['split']('|'), _0x413972 = _0x243199['toString']()[_0x49b81c(0x2d4)](0x1, _0x243199[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText['toString']()[_0x49b81c(0x30b)]('|'));
                                                                                                                            for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9[_0x49b81c(0x2ca)]; _0x3a6f03++) {
                                                                                                                                _0x4f8ea9[_0x3a6f03]['length'] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1], _0x2b4943 = _0x4f41ec[_0x3a6f03 - 0x1]);
                                                                                                                            }
                                                                                                                            if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943[_0x49b81c(0x289)](), setTimeout(function() {
                                                                                                                                var _0x1d2574 = _0x49b81c;
                                                                                                                                $('#loadingimg')[_0x1d2574(0x2eb)](0x1f4), document[_0x1d2574(0x207)](_0x1d2574(0x283))[_0x1d2574(0x295)] = !![];
                                                                                                                            }, 0x7d0);
                                                                                                                            else {
                                                                                                                                if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == ![]) {
                                                                                                                                    _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                    var _0x2b996f = new Array(),
                                                                                                                                        _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                    _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == 'POST' ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]);
                                                                                                                                } else {
                                                                                                                                    if (_0x243199[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) {
                                                                                                                                        _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                        var _0x2b996f = new Array(),
                                                                                                                                            _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                        _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == _0x49b81c(0x2ea) ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]);
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        } else {
                                                                                                                            if (_searchType == '3' && _regx_api != '' && (_0x5d77a6[_0x49b81c(0x25b)](_0x46f2fa) || _0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) || _0x243199[_0x49b81c(0x25b)](_0x46f2fa)) && !lang_Hindi) {
                                                                                                                                var _0x2c64e3, _0x4a70a4 = ![],
                                                                                                                                    _0x43d81a, _0x335edd, _0x27dea0, _0x2b4943, _0x4f8ea9, _0x42d590, _0x413972, _0x4f41ec;
                                                                                                                                if (_regx_api[_0x49b81c(0x2b1)]() != _regx_with_pfix[_0x49b81c(0x2b1)]()) _0x4a70a4 = !![];
                                                                                                                                if (_0x5d77a6[_0x49b81c(0x25b)](_0x46f2fa)) _0x2c64e3 = _0x5d77a6['exec'](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','), _0x42d590 = _0x5d77a6[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x5d77a6['toString']()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText['toString']()[_0x49b81c(0x30b)]('|');
                                                                                                                                else {
                                                                                                                                    if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa)) _0x2c64e3 = _0x3a470c[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','), _0x42d590 = _0x3a470c[_0x49b81c(0x289)]()['substring'](0x1, _0x3a470c['toString']()[_0x49b81c(0x2ca)] - 0x1)['split']('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|');
                                                                                                                                    else _0x243199[_0x49b81c(0x25b)](_0x46f2fa) && (_0x2c64e3 = _0x243199[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','), _0x42d590 = _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x3a470c[_0x49b81c(0x289)]()['length'] - 0x1)[_0x49b81c(0x30b)]('|'), _0x413972 = _0x243199['toString']()[_0x49b81c(0x2d4)](0x1, _0x243199['toString']()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|'));
                                                                                                                                }
                                                                                                                                for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9['length']; _0x3a6f03++) {
                                                                                                                                    _0x4f8ea9[_0x3a6f03][_0x49b81c(0x2ca)] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1], _0x2b4943 = _0x4f41ec[_0x3a6f03 - 0x1]);
                                                                                                                                }
                                                                                                                                if (_0x5d77a6[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943[_0x49b81c(0x289)](), setTimeout(function() {
                                                                                                                                    var _0x34839a = _0x49b81c;
                                                                                                                                    $(_0x34839a(0x2f4))[_0x34839a(0x2eb)](0x1f4), document[_0x34839a(0x207)](_0x34839a(0x283))[_0x34839a(0x295)] = !![];
                                                                                                                                }, 0x7d0);
                                                                                                                                else {
                                                                                                                                    if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943['toString'](), setTimeout(function() {
                                                                                                                                        var _0x3cddb4 = _0x49b81c;
                                                                                                                                        $(_0x3cddb4(0x2f4))[_0x3cddb4(0x2eb)](0x1f4), document['getElementById']('message')[_0x3cddb4(0x295)] = !![];
                                                                                                                                    }, 0x7d0);
                                                                                                                                    else {
                                                                                                                                        if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == ![]) {
                                                                                                                                            _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                            var _0x2b996f = new Array(),
                                                                                                                                                _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                            _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == 'POST' ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1][_0x49b81c(0x24b)]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1]['ResponseKeyWords']);
                                                                                                                                        } else {
                                                                                                                                            if (_0x243199['test'](_0x46f2fa) && _0x4a70a4 == !![]) {
                                                                                                                                                _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                                var _0x2b996f = new Array(),
                                                                                                                                                    _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                                _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == _0x49b81c(0x2ea) ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1]['ResponseKeyWords']) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1]['ResponseKeyWords']);
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            } else {
                                                                                                                                if (/^hi$|^hell?o|^howdy|^नमस्ते|^नमस्कार/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_greetMsgH + '\x20' + $userName, 'मैं\x20निक्की,\x20' + _portalName + _0x49b81c(0x282)];
                                                                                                                                else {
                                                                                                                                    if (/bye|ciao|adieu|salu/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x21d)];
                                                                                                                                    else {
                                                                                                                                        if (/good morning|good evening|good afternoon|good night|शुभ प्रभात|शुभ रात्री|शुभ रात्रि|शुभप्रभात|शुभरात्रि|शुभरात्री/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = [getTimeSalutation() + '\x20' + $userName];
                                                                                                                                        else {
                                                                                                                                            if (/please help me|help me|please suggest me|guide me|suggest me|कृपया मेरी मदद करें|मेरी मदद करें|कृपया मुझे सुझाव दें|मुझे सुझाव दें|मेरा मार्गदर्शन करे/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x24a)];
                                                                                                                                            else {
                                                                                                                                                if (/do you understand|do you understand me|क्या आप मुझे समझती हैं|आप मुझे समझती हैं/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x264)];
                                                                                                                                                else {
                                                                                                                                                    if (/who are you|तुम कौन हो|आप कौन हो/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x31f) + _portalName + '\x20से\x20संबंधित\x20किसी\x20भी\x20जानकारी\x20के\x20लिए\x20आपकी\x20डिजिटल\x20असिस्टेंट\x20।'];
                                                                                                                                                    else {
                                                                                                                                                        if (/what is your name|your name|tell me your name|तुम्हारा नाम क्या है|आपका नाम क्या है|अपना नाम बताए|तुम्हारा नाम/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = ['में\x20निक्की\x20हूँ'];
                                                                                                                                                        else {
                                                                                                                                                            if (/how can you help me|तुम मेरी मदद कैसे कर सकती हो/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = ['आप\x20मुझसे\x20' + _portalName + _0x49b81c(0x2b3)];
                                                                                                                                                            else {
                                                                                                                                                                if (/which languages do you speak|in which languages do you speak|आप कौन कौन सी भाषाएं बोलती हैं/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = ['मैं\x20हिंदी\x20और\x20अंग्रेजी\x20दोनों\x20भाषाओं\x20में\x20बोल\x20सकती\x20हूँ'];
                                                                                                                                                                else {
                                                                                                                                                                    if (/how are you|क्या हाल है|आप कैसी है/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x2cb)];
                                                                                                                                                                    else {
                                                                                                                                                                        if (/are you human|are you real|क्या तुम इंसान हो|क्या तुम वास्तविक हो|क्या आप वास्तविक हो/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x231)];
                                                                                                                                                                        else {
                                                                                                                                                                            if (/are you still there|were are you|तुम अभी भी वहां हो|तुम कहाँ हो|कहाँ हो/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x22d) + _portalName + '\x20से\x20संबन्धित\x20क्या\x20सहायता\x20कर\x20सकती\x20हूँ'];
                                                                                                                                                                            else {
                                                                                                                                                                                if (/are you a boy or girl|you are boy or girl|are you boy or girl|तुम लडका हो या लड़की|आप लडका हो या लड़की/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x231)];
                                                                                                                                                                                else {
                                                                                                                                                                                    if (/tell me about yourself|your introduction|introduce yourself|मुझे अपने बारे में बताओ|आपका परिचय|अपना परिचय दो/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x276), _0x49b81c(0x231), _portalName + _0x49b81c(0x282)];
                                                                                                                                                                                    else {
                                                                                                                                                                                        if (/^धन्यवाद$|^बहुत बहुत धन्यवाद|^शुक्रिया$/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x2be) + ($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : ''), 'धन्यवाद'];
                                                                                                                                                                                        else {
                                                                                                                                                                                            if (/^दिनांक|^आज दिनांक|^तारीख|आज तारीख क्या है|आज दिनांक क्या है/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + 'आज\x20' + getFullDate() + _0x49b81c(0x228)];
                                                                                                                                                                                            else {
                                                                                                                                                                                                if (/^वर्तमान समय|अभी समय क्या हुआ है|निक्की समय क्या हुआ है/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + '\x20' + date[_0x49b81c(0x2d3)]([], {
                                                                                                                                                                                                    'hour': '2-digit',
                                                                                                                                                                                                    'minute': _0x49b81c(0x235),
                                                                                                                                                                                                    'second': _0x49b81c(0x235)
                                                                                                                                                                                                }) + _0x49b81c(0x212)];
                                                                                                                                                                                                else {
                                                                                                                                                                                                    if (/^चालू वित्तीय वर्ष|^वित्तीय वर्ष|वर्तमान वित्तीय वर्ष/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [($userName['length'] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x2d8) + _financialYear + '\x20हैं'];
                                                                                                                                                                                                    else {
                                                                                                                                                                                                        if (/सप्ताह का वार|सप्ताह का दिन|वर्तमान दिन|साप्ताहिक दिन|^दिन|^वार|आज कौनसा दिन हैं|आज कौनसा वार हैं/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x2c1) + getDayOfWeek() + _0x49b81c(0x2ba)];
                                                                                                                                                                                                        else {
                                                                                                                                                                                                            if (/^महिना|वार्षिक माह|^माह|वर्तमान माह का नाम|वर्तमान माह|वर्तमान महिना/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = [($userName['length'] > 0x0 ? $userName + ',\x20' : '') + _0x49b81c(0x24f) + getMonthOfYear() + _0x49b81c(0x2ba)];
                                                                                                                                                                                                            else {
                                                                                                                                                                                                                if (/चैटबॉट क्या हैं|चैटबॉट क्या होता हैं|चैटबॉट मतलब|चैटबॉट|बॉट क्या हैं/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi) _0x132de8 = [_0x49b81c(0x24d), _0x49b81c(0x22f)];
                                                                                                                                                                                                                else {
                                                                                                                                                                                                                    if (/कृपया मुझे मेरा नाम बताओ|मेरा नाम क्या है|मेरा नाम बताओ|मेरा नाम/ ['test'](_0x1f043b) && lang_Hindi) _0x132de8 = ['' + ($userName[_0x49b81c(0x2ca)] > 0x0 ? 'आपका\x20नाम\x20' + $userName + _0x49b81c(0x2ba) : _0x49b81c(0x297))];
                                                                                                                                                                                                                    else {
                                                                                                                                                                                                                        if (/(?=.*hindi)((?=.*speak)|(?=.*baat)|(?=.*type)|(?=.*talk)|(?=.*language)|(?=.*bolo)|(?=.*likho)).*|(?=.*english)((?=.*mat)|(?=.*nahi)|(?=.*not))(?=.*baat).*|((?=.*not)|(?=.*nahi)|(?=.*mat))((?=.*speak)|(?=.*baat)|(?=.*chat)|(?=.*bolo))(?=.*english).*|(?=.*hindi)(?=.*bat).*|(?=.*hindi)(?=.*understand)(?=.*in).*|^hindi please/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi && _isBiLang[_0x49b81c(0x1ec)]() == 'true') _0x132de8 = [_0x49b81c(0x331)];
                                                                                                                                                                                                                        else {
                                                                                                                                                                                                                            if (/((?=.*hindi)|(?=.*हिन्दी))((?=.*मत)|(?=.*mat)|(?=.*nahi)|(?=.*नहीं)|(?=.*not))((?=.*speak)|(?=.*chat)|(?=.*talk)|(?=.*baat)|(?=.*बात)|(?=.*बोलो)).*|((?=.*english)|(?=.*अँग्रेजी)|(?=.*इंग्लिश))((?=.*in)|(?=.*mai)|(?=.*mein))((?=.*speak)|(?=.*chat)|(?=.*talk)|(?=.*baat)).*|speak english/ [_0x49b81c(0x25b)](_0x1f043b) && lang_Hindi && _isBiLang[_0x49b81c(0x1ec)]() == _0x49b81c(0x26e)) $('#ctl01_chkLang')['removeProp'](_0x49b81c(0x2c9)), lang_Hindi = $('#ctl01_chkLang')['prop'](_0x49b81c(0x2c9)), $(_0x49b81c(0x29a))[_0x49b81c(0x261)](_0x49b81c(0x1bb), _0x49b81c(0x308)), $('.tooltiptext')['text'](_0x49b81c(0x27d)), recognition['lang'] = _0x49b81c(0x253), noteContent = '', window[_0x49b81c(0x309)][_0x49b81c(0x2f5)](), _0x132de8 = ['' + ($userName[_0x49b81c(0x2ca)] > 0x0 ? $userName + _0x49b81c(0x200) : 'Please\x20chat\x20in\x20English\x20language\x20now.')];
                                                                                                                                                                                                                            else {
                                                                                                                                                                                                                                if (_searchType == '1' && _regx != '' && _0x5d77a6['test'](_0x46f2fa) && lang_Hindi) {
                                                                                                                                                                                                                                    var _0x2c64e3 = _0x5d77a6['exec'](_0x46f2fa),
                                                                                                                                                                                                                                        _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()[_0x49b81c(0x30b)](','),
                                                                                                                                                                                                                                        _0x42d590 = _0x5d77a6[_0x49b81c(0x289)]()['substring'](0x1, _0x5d77a6[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'),
                                                                                                                                                                                                                                        _0x43d81a, _0x27dea0;
                                                                                                                                                                                                                                    for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9[_0x49b81c(0x2ca)]; _0x3a6f03++) {
                                                                                                                                                                                                                                        _0x4f8ea9[_0x3a6f03][_0x49b81c(0x2ca)] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1]);
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    $[_0x49b81c(0x1d3)]({
                                                                                                                                                                                                                                        'type': _0x49b81c(0x2ea),
                                                                                                                                                                                                                                        'url': _0xe15569 + '/chatbotService.asmx/SearchResponse',
                                                                                                                                                                                                                                        'data': _0x49b81c(0x2fd) + _0x43d81a + _0x49b81c(0x1ff) + _0x27dea0 + _0x49b81c(0x2fc) + $('#ctl01_hdnToken')['val']() + '\x22,\x22inhindi\x22:\x20\x22' + lang_Hindi + '\x22,\x22searchType\x22:\x20\x22' + _searchType + '\x22}',
                                                                                                                                                                                                                                        'contentType': _0x49b81c(0x32e),
                                                                                                                                                                                                                                        'dataType': 'json',
                                                                                                                                                                                                                                        'async': ![],
                                                                                                                                                                                                                                        'success': function(_0x1feb82) {
                                                                                                                                                                                                                                            var _0x2e89f9 = _0x49b81c,
                                                                                                                                                                                                                                                _0x58da99 = JSON[_0x2e89f9(0x32d)](_0x1feb82['d']);
                                                                                                                                                                                                                                            if (_0x58da99['length'] > 0x0) {
                                                                                                                                                                                                                                                if (_0x58da99[0x0]['ResponseKeyWords']['trim']()[_0x2e89f9(0x2ca)] > 0x0) _0x132de8 = _0x58da99[0x0][_0x2e89f9(0x24b)][_0x2e89f9(0x30b)]('|'), invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                else {
                                                                                                                                                                                                                                                    invalidSearchCount++;
                                                                                                                                                                                                                                                    if (invalidSearchCount == 0x2) {
                                                                                                                                                                                                                                                        if (!lang_Hindi) _0x132de8 = ['Maybe\x20I\x20did\x20not\x20understand\x20you\x20properly.', _0x2e89f9(0x1ea)];
                                                                                                                                                                                                                                                        else _0x132de8 = [_0x2e89f9(0x287), 'कृपया\x20अपना\x20प्रश्न\x20पुनः\x20लिखें\x20या\x20अपनी\x20पूरी\x20क्वेरी\x20टाइप\x20करें\x20।'];
                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                        if (invalidSearchCount == 0x3) {
                                                                                                                                                                                                                                                            if (!lang_Hindi) _0x132de8 = ['Sometimes\x20I\x20may\x20not\x20have\x20the\x20information\x20you\x20need.', '' + _helplineMsg];
                                                                                                                                                                                                                                                            else _0x132de8 = [_0x2e89f9(0x26a), '' + _hhelplineMsg];
                                                                                                                                                                                                                                                            invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                invalidSearchCount++;
                                                                                                                                                                                                                                                if (invalidSearchCount == 0x2) {
                                                                                                                                                                                                                                                    if (!lang_Hindi) _0x132de8 = [_0x2e89f9(0x23c), _0x2e89f9(0x1ea)];
                                                                                                                                                                                                                                                    else _0x132de8 = [_0x2e89f9(0x287), _0x2e89f9(0x2f9)];
                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                    if (invalidSearchCount == 0x3) {
                                                                                                                                                                                                                                                        if (!lang_Hindi) _0x132de8 = [_0x2e89f9(0x23f), '' + _helplineMsg];
                                                                                                                                                                                                                                                        else _0x132de8 = ['कभी-कभी\x20मेरे\x20पास\x20आपकी\x20द्वारा\x20पूछी\x20गयी\x20आवश्यक\x20जानकारी\x20नहीं\x20हो\x20सकती\x20है\x20।', '' + _hhelplineMsg];
                                                                                                                                                                                                                                                        invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        },
                                                                                                                                                                                                                                        'failure': function(_0xec2f61) {},
                                                                                                                                                                                                                                        'error': function(_0x2cc591) {}
                                                                                                                                                                                                                                    });
                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                    if (_searchType == '2' && _regx_api != '' && (_0x3a470c['test'](_0x46f2fa) || _0x243199[_0x49b81c(0x25b)](_0x46f2fa)) && lang_Hindi) {
                                                                                                                                                                                                                                        var _0x2c64e3, _0x4a70a4 = ![],
                                                                                                                                                                                                                                            _0x43d81a, _0x335edd, _0x27dea0, _0x2b4943, _0x4f8ea9, _0x42d590, _0x413972, _0x4f41ec;
                                                                                                                                                                                                                                        if (_regx_api['trim']() != _regx_with_pfix['trim']()) _0x4a70a4 = !![];
                                                                                                                                                                                                                                        if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa)) _0x2c64e3 = _0x3a470c['exec'](_0x46f2fa), _0x4f8ea9 = _0x2c64e3['toString']()[_0x49b81c(0x30b)](','), _0x42d590 = _0x3a470c['toString']()[_0x49b81c(0x2d4)](0x1, _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)['split']('|'), _0x4f41ec = _formatText['toString']()['split']('|');
                                                                                                                                                                                                                                        else _0x243199['test'](_0x46f2fa) && (_0x2c64e3 = _0x243199[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()['split'](','), _0x42d590 = _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)['split']('|'), _0x413972 = _0x243199[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x243199[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()['split']('|'));
                                                                                                                                                                                                                                        for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9[_0x49b81c(0x2ca)]; _0x3a6f03++) {
                                                                                                                                                                                                                                            _0x4f8ea9[_0x3a6f03][_0x49b81c(0x2ca)] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1], _0x2b4943 = _0x4f41ec[_0x3a6f03 - 0x1]);
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        if (_0x3a470c['test'](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943[_0x49b81c(0x289)](), setTimeout(function() {
                                                                                                                                                                                                                                            var _0x4356b0 = _0x49b81c;
                                                                                                                                                                                                                                            $('#loadingimg')['hide'](0x1f4), document[_0x4356b0(0x207)](_0x4356b0(0x283))[_0x4356b0(0x295)] = !![];
                                                                                                                                                                                                                                        }, 0x7d0);
                                                                                                                                                                                                                                        else {
                                                                                                                                                                                                                                            if (_0x3a470c['test'](_0x46f2fa) && _0x4a70a4 == ![]) {
                                                                                                                                                                                                                                                _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                                                                                                                                var _0x2b996f = new Array(),
                                                                                                                                                                                                                                                    _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                                                                                                                                _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == 'POST' ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]);
                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                if (_0x243199[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) {
                                                                                                                                                                                                                                                    _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                                                                                                                                    var _0x2b996f = new Array(),
                                                                                                                                                                                                                                                        _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                                                                                                                                    _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == _0x49b81c(0x2ea) ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4]);
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                        if (_searchType == '3' && _regx_api != '' && (_0x5d77a6['test'](_0x46f2fa) || _0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) || _0x243199[_0x49b81c(0x25b)](_0x46f2fa)) && lang_Hindi) {
                                                                                                                                                                                                                                            var _0x2c64e3, _0x4a70a4 = ![],
                                                                                                                                                                                                                                                _0x43d81a, _0x335edd, _0x27dea0, _0x2b4943, _0x4f8ea9, _0x42d590, _0x413972, _0x4f41ec;
                                                                                                                                                                                                                                            if (_regx_api[_0x49b81c(0x2b1)]() != _regx_with_pfix['trim']()) _0x4a70a4 = !![];
                                                                                                                                                                                                                                            if (_0x5d77a6[_0x49b81c(0x25b)](_0x46f2fa)) _0x2c64e3 = _0x5d77a6[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()['split'](','), _0x42d590 = _0x5d77a6[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x5d77a6[_0x49b81c(0x289)]()['length'] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|');
                                                                                                                                                                                                                                            else {
                                                                                                                                                                                                                                                if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa)) _0x2c64e3 = _0x3a470c[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3[_0x49b81c(0x289)]()['split'](','), _0x42d590 = _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2d4)](0x1, _0x3a470c['toString']()['length'] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|');
                                                                                                                                                                                                                                                else _0x243199[_0x49b81c(0x25b)](_0x46f2fa) && (_0x2c64e3 = _0x243199[_0x49b81c(0x285)](_0x46f2fa), _0x4f8ea9 = _0x2c64e3['toString']()[_0x49b81c(0x30b)](','), _0x42d590 = _0x3a470c['toString']()[_0x49b81c(0x2d4)](0x1, _0x3a470c[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x413972 = _0x243199['toString']()[_0x49b81c(0x2d4)](0x1, _0x243199[_0x49b81c(0x289)]()[_0x49b81c(0x2ca)] - 0x1)[_0x49b81c(0x30b)]('|'), _0x4f41ec = _formatText[_0x49b81c(0x289)]()[_0x49b81c(0x30b)]('|'));
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            for (var _0x3a6f03 = 0x1; _0x3a6f03 < _0x4f8ea9[_0x49b81c(0x2ca)]; _0x3a6f03++) {
                                                                                                                                                                                                                                                _0x4f8ea9[_0x3a6f03][_0x49b81c(0x2ca)] > 0x0 && (_0x27dea0 = _0x4f8ea9[_0x3a6f03], _0x43d81a = _0x42d590[_0x3a6f03 - 0x1], _0x2b4943 = _0x4f41ec[_0x3a6f03 - 0x1]);
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            if (_0x5d77a6[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943['toString'](), setTimeout(function() {
                                                                                                                                                                                                                                                var _0x550e80 = _0x49b81c;
                                                                                                                                                                                                                                                $(_0x550e80(0x2f4))[_0x550e80(0x2eb)](0x1f4), document[_0x550e80(0x207)]('message')['contentEditable'] = !![];
                                                                                                                                                                                                                                            }, 0x7d0);
                                                                                                                                                                                                                                            else {
                                                                                                                                                                                                                                                if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == !![]) _0x132de8 = _0x2b4943[_0x49b81c(0x289)](), setTimeout(function() {
                                                                                                                                                                                                                                                    var _0x40b970 = _0x49b81c;
                                                                                                                                                                                                                                                    $(_0x40b970(0x2f4))['hide'](0x1f4), document[_0x40b970(0x207)](_0x40b970(0x283))[_0x40b970(0x295)] = !![];
                                                                                                                                                                                                                                                }, 0x7d0);
                                                                                                                                                                                                                                                else {
                                                                                                                                                                                                                                                    if (_0x3a470c[_0x49b81c(0x25b)](_0x46f2fa) && _0x4a70a4 == ![]) {
                                                                                                                                                                                                                                                        _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                                                                                                                                        var _0x2b996f = new Array(),
                                                                                                                                                                                                                                                            _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                                                                                                                                        _0x2b996f = _0x59dd9d['split']('|'), _0x2b996f[0x2] == 'POST' ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1][_0x49b81c(0x24b)]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1][_0x49b81c(0x24b)]);
                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                        if (_0x243199['test'](_0x46f2fa) && _0x4a70a4 == !![]) {
                                                                                                                                                                                                                                                            _0x132de8 = _callAjax(_0xe15569, _0x43d81a, _0x27dea0, lang_Hindi, _searchType);
                                                                                                                                                                                                                                                            var _0x2b996f = new Array(),
                                                                                                                                                                                                                                                                _0x59dd9d = _0x132de8[0x0][_0x49b81c(0x24b)];
                                                                                                                                                                                                                                                            _0x2b996f = _0x59dd9d[_0x49b81c(0x30b)]('|'), _0x2b996f[0x2] == _0x49b81c(0x2ea) ? _0x132de8 = ClAxPtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1][_0x49b81c(0x24b)]) : _0x132de8 = ClAxGtAi(_0x2b996f[0x0], _0x2b996f[0x1], _0x2b996f[0x3], _0x2b996f[0x4], _0x132de8[0x1][_0x49b81c(0x24b)]);
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                            if (_0x132de8[_0x49b81c(0x2ca)] <= 0x0) {
                                                                                                                                                                                                                                                if (!lang_Hindi) _0x132de8 = [_0x49b81c(0x2d9), _0x49b81c(0x259)];
                                                                                                                                                                                                                                                else _0x132de8 = [_0x49b81c(0x223), _0x49b81c(0x2ad)];
                                                                                                                                                                                                                                                $[_0x49b81c(0x1d3)]({
                                                                                                                                                                                                                                                    'type': _0x49b81c(0x2ea),
                                                                                                                                                                                                                                                    'url': _0xe15569 + _0x49b81c(0x244),
                                                                                                                                                                                                                                                    'data': '{\x22requestedkeywords\x22:\x22' + _0x1f043b + _0x49b81c(0x2fc) + $(_0x49b81c(0x1f2))['val']() + _0x49b81c(0x29e) + lang_Hindi + '\x22}',
                                                                                                                                                                                                                                                    'contentType': _0x49b81c(0x32e),
                                                                                                                                                                                                                                                    'dataType': _0x49b81c(0x28d),
                                                                                                                                                                                                                                                    'async': ![],
                                                                                                                                                                                                                                                    'success': function(_0x13dcda) {
                                                                                                                                                                                                                                                        var _0x53cce2 = _0x49b81c,
                                                                                                                                                                                                                                                            _0x3953ff = JSON[_0x53cce2(0x32d)](_0x13dcda['d']);
                                                                                                                                                                                                                                                        if (_0x3953ff['length'] > 0x0) {
                                                                                                                                                                                                                                                            if (_0x3953ff[0x0][_0x53cce2(0x24b)][_0x53cce2(0x2b1)]()[_0x53cce2(0x2ca)] > 0x0) _0x132de8 = _0x3953ff[0x0][_0x53cce2(0x24b)][_0x53cce2(0x30b)]('|'), invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                            else {
                                                                                                                                                                                                                                                                invalidSearchCount++;
                                                                                                                                                                                                                                                                if (invalidSearchCount == 0x2) {
                                                                                                                                                                                                                                                                    if (!lang_Hindi) _0x132de8 = [_0x53cce2(0x23c), 'Please\x20retype\x20your\x20question\x20or\x20type\x20your\x20complete\x20query.'];
                                                                                                                                                                                                                                                                    else _0x132de8 = ['शायद\x20मैं\x20आपके\x20प्रश्न\x20को\x20ठीक\x20से\x20समझ\x20नहीं\x20पायी\x20।', 'कृपया\x20अपना\x20प्रश्न\x20पुनः\x20लिखें\x20या\x20अपनी\x20पूरी\x20क्वेरी\x20टाइप\x20करें\x20।'];
                                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                                    if (invalidSearchCount == 0x3) {
                                                                                                                                                                                                                                                                        if (!lang_Hindi) _0x132de8 = ['Sometimes\x20I\x20may\x20not\x20have\x20the\x20information\x20you\x20need.', '' + _helplineMsg];
                                                                                                                                                                                                                                                                        else _0x132de8 = [_0x53cce2(0x26a), '' + _hhelplineMsg];
                                                                                                                                                                                                                                                                        invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                                                            invalidSearchCount++;
                                                                                                                                                                                                                                                            if (invalidSearchCount == 0x2) {
                                                                                                                                                                                                                                                                if (!lang_Hindi) _0x132de8 = ['Maybe\x20I\x20did\x20not\x20understand\x20you\x20properly.', _0x53cce2(0x1ea)];
                                                                                                                                                                                                                                                                else _0x132de8 = [_0x53cce2(0x287), 'कृपया\x20अपना\x20प्रश्न\x20पुनः\x20लिखें\x20या\x20अपनी\x20पूरी\x20क्वेरी\x20टाइप\x20करें\x20।'];
                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                if (invalidSearchCount == 0x3) {
                                                                                                                                                                                                                                                                    if (!lang_Hindi) _0x132de8 = [_0x53cce2(0x23f), '' + _helplineMsg];
                                                                                                                                                                                                                                                                    else _0x132de8 = [_0x53cce2(0x26a), '' + _hhelplineMsg];
                                                                                                                                                                                                                                                                    invalidSearchCount = 0x0;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    },
                                                                                                                                                                                                                                                    'failure': function(_0x43906b) {},
                                                                                                                                                                                                                                                    'error': function(_0x318060) {}
                                                                                                                                                                                                                                                });
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }
                                                                                                                                                                                                }
                                                                                                                                                                                            }
                                                                                                                                                                                        }
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                            }
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return _0x132de8;
};

function _callAjax(_0x11e782, _0x2f831c, _0x578818, _0x86bdd0, _0x5835de) {
    var _0x40a0f0 = _0xb72139,
        _0x5ed9d7;
    return $['ajax']({
        'type': _0x40a0f0(0x2ea),
        'url': _0x11e782 + _0x40a0f0(0x31b),
        'data': _0x40a0f0(0x2fd) + _0x2f831c + _0x40a0f0(0x1ff) + _0x578818 + _0x40a0f0(0x2fc) + $(_0x40a0f0(0x1f2))[_0x40a0f0(0x203)]() + _0x40a0f0(0x29e) + _0x86bdd0 + _0x40a0f0(0x245) + _0x5835de + '\x22}',
        'contentType': _0x40a0f0(0x32e),
        'dataType': 'json',
        'async': ![],
        'success': function(_0x245e7f) {
            var _0x5a9b33 = _0x40a0f0;
            try {
                _0x5ed9d7 = JSON['parse'](_0x245e7f['d']);
            } catch (_0x26f5ad) {
                _0x5ed9d7 = _0x5a9b33(0x2c8);
            }
        },
        'failure': function(_0x18e95f) {
            var _0x3f94e4 = _0x40a0f0;
            _0x5ed9d7 = _0x3f94e4(0x2c8);
        },
        'error': function(_0x17601b) {
            var _0x433c92 = _0x40a0f0;
            _0x5ed9d7 = _0x433c92(0x2c8);
        }
    }), _0x5ed9d7;
}

function postBotReply(_0xc89c1) {
    var _0x221a83 = _0xb72139;
    const _0x456cf7 = timeStamp()[_0x221a83(0x1cc)]('<span\x20class=\x22timestamp\x22>', '')['replace'](_0x221a83(0x2a7), ''),
        _0x3ac5d4 = _0x221a83(0x31e) + _0x456cf7 + '\x27>' + (_0xc89c1 + timeStamp()) + _0x221a83(0x1c0) + getRootWebSitePath() + 'images/mili.png\x20style=\x22width:\x2030px;\x20border-radius:\x2025px;\x20max-width:\x2030px\x20!important;\x22>\x20</div></div>';
    var _0x4d01de = _0x221a83(0x1e6) + _0xc89c1 + _0x221a83(0x1f4);
    const _0x4b6122 = 0x1f4 + Math[_0x221a83(0x1ca)](Math[_0x221a83(0x2d0)]() * 0x7d0);
    $('#message-board')['append'](_0x3ac5d4);
    var _0x190b1a = '';
    if ($(_0x4d01de)['text']()[_0x221a83(0x2ca)] > 0x0) _0x190b1a = $(_0x4d01de)[_0x221a83(0x2f8)]()[_0x221a83(0x2b1)]();
    else _0x190b1a = _0xc89c1;
    if (!isVoicemute) {
        var _0x267680 = replaceAll(_0x190b1a, _0x221a83(0x307), _0x221a83(0x201)),
            _0xc7b279 = replaceAll(_0x267680, '/-', ''),
            _0x33a0e3 = replaceAll(_0xc7b279, '/', _0x221a83(0x319)),
            _0x1d003f = replaceAll(_0x33a0e3, 'NICCI', '\x20Nikki\x20');
        speak(_0x1d003f);
    }
    $scrollDown();
};

function postBotKeywords(_0x1ad6d7) {
    var _0x1a4f4a = _0xb72139,
        _0x1d4c75, _0x454816 = !![],
        _0x2b2cc8 = !![],
        _0x43cfe7 = _0x1a4f4a(0x1d9) + $[_0x1a4f4a(0x2b1)](_portalName) + _0x1a4f4a(0x2ed),
        _0x3fa08d = _0x1a4f4a(0x2ae) + $[_0x1a4f4a(0x2b1)](_portalName) + _0x1a4f4a(0x2b0);
    if (_helplineMsg == _0x43cfe7 || _helplineMsg['length'] == 0x0) _0x454816 = ![];
    if (_hhelplineMsg == _0x3fa08d || _hhelplineMsg['length'] == 0x0) _0x2b2cc8 = ![];
    !lang_Hindi ? (_0x1d4c75 = _0x1a4f4a(0x2e0), _0x1d4c75 += 'Please\x20choose\x20one\x20of\x20the\x20below\x20suggested\x20questions:</span><ul\x20style=\x22padding-left:\x2023px\x20!important;float:left\x20!important;\x22>') : (_0x1d4c75 = '<div\x20class=\x22tags\x22><span>कृपया\x20सार्थक\x20प्रश्न\x20पूछें\x20।\x20', _0x1d4c75 += _0x1a4f4a(0x234));
    var _0x1422ef = _0x1ad6d7[_0x1a4f4a(0x30b)]('$');
    for (var _0x1e3369 = 0x0; _0x1e3369 < _0x1422ef[_0x1a4f4a(0x2ca)]; _0x1e3369++) {
        if (_0x1e3369 < 0x5) _0x1d4c75 += _0x1a4f4a(0x1fc) + _0x1422ef[_0x1e3369] + _0x1a4f4a(0x286) + _0x1422ef[_0x1e3369] + '</a></li>';
        else _0x1d4c75 += _0x1a4f4a(0x2f2) + _0x1422ef[_0x1e3369] + _0x1a4f4a(0x286) + _0x1422ef[_0x1e3369] + _0x1a4f4a(0x1d7);
    }
    _0x1422ef[_0x1a4f4a(0x2ca)] > 0x5 ? !lang_Hindi ? _0x454816 ? (_0x1d4c75 += '<li\x20class=\x22kwm\x22\x20><a\x20style=\x22color:#0008ff\x20!important;\x22\x20onclick=\x22$(\x27.tags\x20li.kwl\x27).fadeIn(1500);$(\x27.tags\x20span.hln\x27).fadeIn(2500);$(this).parent().hide();$scrollDown();\x22>more\x20...</a></li>', _0x1d4c75 += '</ul><span\x20class=\x22hln\x22\x20style=\x27display:none;\x27><a\x20onclick=\x22postBotReply([\x27' + _helplineMsg + _0x1a4f4a(0x22a)) : _0x1d4c75 += _0x1a4f4a(0x31a) : _0x2b2cc8 ? (_0x1d4c75 += _0x1a4f4a(0x27f), _0x1d4c75 += _0x1a4f4a(0x249) + _hhelplineMsg + '\x27]);\x22><b>हेल्पलाइन\x20नंबर</b></a></span></div>') : _0x1d4c75 += _0x1a4f4a(0x31a) : !lang_Hindi ? _0x454816 ? _0x1d4c75 += _0x1a4f4a(0x229) + _helplineMsg + _0x1a4f4a(0x22a) : _0x1d4c75 += _0x1a4f4a(0x27a) : _0x2b2cc8 ? _0x1d4c75 += _0x1a4f4a(0x229) + _hhelplineMsg + '\x27]);\x22><b>हेल्पलाइन\x20नंबर</b></a></span></div>' : _0x1d4c75 += _0x1a4f4a(0x27a);
    $(_0x1a4f4a(0x1d2))[_0x1a4f4a(0x2d5)](_0x1d4c75);
    if (!lang_Hindi) speak(_0x1a4f4a(0x322));
    else speak(_0x1a4f4a(0x2aa));
    $scrollDown();
}

function timeStamp() {
    var _0x10e964 = _0xb72139;
    const _0x268745 = new Date(),
        _0x1046b8 = _0x268745['getHours']();
    let _0xca5e2 = _0x268745[_0x10e964(0x29b)]();
    if (_0xca5e2 < 0xa) _0xca5e2 = '0' + _0xca5e2;
    let _0x977a6c = _0x268745[_0x10e964(0x29c)]();
    if (_0x977a6c < 0xa) _0x977a6c = '0' + _0x977a6c;
    let _0x48229f = _0x268745[_0x10e964(0x1f8)]();
    if (_0x48229f < 0xa) _0x48229f = '0' + _0x48229f;
    const _0x3c956f = _0x10e964(0x2a1) + _0x1046b8 + ':' + _0xca5e2 + ':' + _0x977a6c + ':' + _0x48229f + _0x10e964(0x2a7);
    return _0x3c956f;
};

function $scrollDown() {
    var _0x4f5140 = _0xb72139;
    const _0x1195d4 = $(_0x4f5140(0x1d2)),
        _0x3cd499 = _0x1195d4['height'](),
        _0x35dfa3 = _0x1195d4[0x0][_0x4f5140(0x2b9)];
    if (_0x35dfa3 > _0x3cd499) _0x1195d4[_0x4f5140(0x215)]({
        'scrollTop': _0x35dfa3
    }, 0x7d0);
    $('#message')['focus']();
}

function StartChat() {
    var _0x44cf55 = _0xb72139;
    $(_0x44cf55(0x2e1))['on']('click', _0x4abb7b => {
        var _0x778436 = _0x44cf55;
        if (!checkRestrictedWords(_0x778436(0x310), _0x778436(0x2d1))) return ![];
        _0x4abb7b[_0x778436(0x332)](), $userName = $(_0x778436(0x2a4))[_0x778436(0x203)](), firstbotReply(), $(_0x778436(0x270))['html'](''), $(_0x778436(0x315))[_0x778436(0x1d6)](0x12c), setTimeout(() => {
            var _0x1b15b2 = _0x778436;
            $(_0x1b15b2(0x2e1))['html']('Continue\x20chat');
        }, 0x12c);
    }), $('#message')['on'](_0x44cf55(0x2ee), _0xf3ae89 => {
        var _0x310a25 = _0x44cf55;
        if (_0xf3ae89[_0x310a25(0x21a)] === 0xd) $postMessage();
    })['on'](_0x44cf55(0x2ab), () => {
        var _0x3f7c41 = _0x44cf55;
        $('#message')[_0x3f7c41(0x1f6)]('focus');
    })['on'](_0x44cf55(0x258), () => {
        var _0x10ff98 = _0x44cf55;
        $(_0x10ff98(0x29a))[_0x10ff98(0x288)](_0x10ff98(0x2ab));
    }), $('#send')['on'](_0x44cf55(0x208), $postMessage), $(_0x44cf55(0x22e))['on'](_0x44cf55(0x208), () => {
        var _0x43252d = _0x44cf55;
        return $(_0x43252d(0x315))['show'](), ![];
    }), $(_0x44cf55(0x26d))['on'](_0x44cf55(0x208), () => {
        var _0x3c4def = _0x44cf55;
        return $(_0x3c4def(0x27b))[_0x3c4def(0x26c)](), ![];
    }), $(_0x44cf55(0x27b))['on'](_0x44cf55(0x25d), () => {
        var _0x5b73ba = _0x44cf55;
        return $(_0x5b73ba(0x27b))[_0x5b73ba(0x2eb)](), ![];
    }), $(_0x44cf55(0x224))['on'](_0x44cf55(0x208), () => {
        var _0x52d311 = _0x44cf55;
        return $('#nav-container1')[_0x52d311(0x32f)](0xc8), ![];
    }), $(_0x44cf55(0x1c7))['on'](_0x44cf55(0x208), () => {
        var _0x1e8b31 = _0x44cf55;
        return $(_0x1e8b31(0x1d2))[_0x1e8b31(0x1fe)](), $('#message')['empty'](), noteContent = '', ![];
    }), $('#sign-out')['on'](_0x44cf55(0x208), () => {
        var _0x7f333e = _0x44cf55;
        return $(_0x7f333e(0x256))['slideDown'](0x3e8, 'swing'), setTimeout(function() {
            var _0x54b047 = _0x7f333e;
            $('#nicciFeebackbox')[_0x54b047(0x2ab)]();
        }, 0x5dc), ![];
    }), $(_0x44cf55(0x28b))['on'](_0x44cf55(0x208), () => {
        var _0x37acd0 = _0x44cf55;
        $(_0x37acd0(0x267))[_0x37acd0(0x32f)](0x12c), $(_0x37acd0(0x28b))[_0x37acd0(0x2b8)](_0x37acd0(0x1e4));
    }), $('.smiley')['on'](_0x44cf55(0x208), _0x421e41 => {
        var _0x2868ff = _0x44cf55;
        const _0x414648 = $(_0x421e41[_0x2868ff(0x269)])[_0x2868ff(0x1cb)]()['contents']()[_0x2868ff(0x1f6)](_0x2868ff(0x318));
        $(_0x2868ff(0x29a))[_0x2868ff(0x2d5)](_0x414648), $(_0x2868ff(0x29a))[_0x2868ff(0x2e2)]();
    }), setTimeout(function() {
        var _0x32005e = _0x44cf55;
        $(_0x32005e(0x2d2))[_0x32005e(0x290)](0x5dc);
    }, 0x7d0);
}

function nicciExitCode() {
    var _0x47dfa6 = _0xb72139;
    $(_0x47dfa6(0x1d2))['empty'](), $(_0x47dfa6(0x29a))[_0x47dfa6(0x1fe)](), noteContent = '', $(_0x47dfa6(0x315))[_0x47dfa6(0x26c)](), $(_0x47dfa6(0x325))[_0x47dfa6(0x2eb)]()[_0x47dfa6(0x288)](_0x47dfa6(0x275))['addClass'](_0x47dfa6(0x2a6))['fadeIn'](0x5dc), $(_0x47dfa6(0x2a4))[_0x47dfa6(0x203)](''), $(_0x47dfa6(0x2e1))[_0x47dfa6(0x28a)](_0x47dfa6(0x1d0)), $(_0x47dfa6(0x270))[_0x47dfa6(0x28a)](_0x47dfa6(0x313)), $(_0x47dfa6(0x205))['html'](''), $(_0x47dfa6(0x1e3))[_0x47dfa6(0x26c)]()[_0x47dfa6(0x203)](''), $(_0x47dfa6(0x1bc))[_0x47dfa6(0x26c)](), $('#nicciSkipBtn')[_0x47dfa6(0x26c)](), $(_0x47dfa6(0x23b))['html'](_0x47dfa6(0x1dc)), $(_0x47dfa6(0x1e9))['show'](), $('#nicciFBClose')[_0x47dfa6(0x26c)](), $(_0x47dfa6(0x263))[_0x47dfa6(0x28a)]('Maximum\x20characters:\x20180'), $('#nicciremainingC')[_0x47dfa6(0x26c)](), $(_0x47dfa6(0x1e9))[_0x47dfa6(0x1e2)](function() {
        var _0xd62a1c = _0x47dfa6;
        $(this)[_0xd62a1c(0x288)](_0xd62a1c(0x2fe));
    });
    if ((_searchType == '2' || _searchType == '3') && _searchSuggestion[_0x47dfa6(0x2b1)]()[_0x47dfa6(0x2ca)] > 0x0) $('#Niccisearchslide')[_0x47dfa6(0x2eb)]();
    return starRating = 0x0, window['speechSynthesis']['cancel'](), ![];
}
min_chat = function() {
    var _0xdf2ee9 = _0xb72139;
    return $(_0xdf2ee9(0x1d2))['empty'](), $(_0xdf2ee9(0x29a))[_0xdf2ee9(0x1fe)](), noteContent = '', ![];
}, exitchat = function() {
    var _0x367bd4 = _0xb72139;
    if ((_searchType == '2' || _searchType == '3') && _searchSuggestion['trim']()[_0x367bd4(0x2ca)] > 0x0) $(_0x367bd4(0x23e))[_0x367bd4(0x1d6)](_0x367bd4(0x2a8));
    return $('#Nicci_feedback')[_0x367bd4(0x304)](0x3e8, 'swing'), setTimeout(function() {
        $('#nicciFeebackbox')['focus']();
    }, 0x5dc), ![];
}, $(document)['ready'](StartChat);

function showPopup(_0x4c2940) {
    var _0x5c65b9 = _0xb72139;
    $(_0x4c2940)['hide'](_0x5c65b9(0x2bb)), $(_0x5c65b9(0x220))[_0x5c65b9(0x26c)]('1500');
}

function hidePopup() {
    var _0x3160be = _0xb72139;
    $(_0x3160be(0x220))[_0x3160be(0x2eb)]('1000'), $(_0x3160be(0x300))[_0x3160be(0x26c)](_0x3160be(0x1f3)), setTimeout(function() {
        var _0x2ad416 = _0x3160be;
        $(_0x2ad416(0x2d2))[_0x2ad416(0x236)]('style');
    }, 0x1f4);
}

function _0x1ae3() {
    var _0x4908b8 = [']+?(?:\x5cs|$)', '<div\x20class=\x22post\x20post-bot\x22>', 'userAgent', 'April', '.nicci-star', 'Please\x20retype\x20your\x20question\x20or\x20type\x20your\x20complete\x20query.', 'DataContent', 'toLowerCase', 'बुधवार', 'rate', '\x20Current\x20financial\x20year\x20is\x20', '\x20.nicci-star', 'I\x20Can\x20Speak\x20in\x20both\x20Hindi\x20&\x20English\x20Languages', '#ctl01_hdnToken', '1500', '</div>', '{\x22requestedkeywords\x22:\x22', 'addClass', 'fadeOut', 'getMilliseconds', 'No,\x20I\x20am\x20AI\x20based\x20Voice\x20Enabled\x20Chatbot', '<li><b>', 'What\x20can\x20I\x20do\x20for\x20you?', '<li\x20class=\x22kwl\x22><a\x20onclick=\x22$(\x27#message\x27).html(\x27', '#spannicci_sound', 'empty', '\x22,\x22matchedKey\x22:\x20\x22', ',\x20Please\x20chat\x20in\x20English\x20language\x20now.', 'Rupees', 'जुलाई', 'val', '</li>', '#suggestionlist', 'Opera', 'getElementById', 'click', 'value', 'hi-IN', '/chatbotService.asmx/getTags', 'Continue\x20chat', '[object\x20SafariRemoteNotification]', 'createElement', 'charCodeAt', 'onvoiceschanged', 'images/userlg.png\x20style=\x22width:\x2030px;border-radius:\x2025px;max-width:\x2030px\x20!important;\x22>\x20</div><div\x20class=\x22post\x20post-user\x22>', '\x20समय\x20हुआ\x20है', 'Remaining\x20characters:\x20', 'मार्च', 'animate', 'voice', 'November', 'chrome', '\x5cu0', 'which', 'October', 'February', 'धन्यवाद\x20।', 'parent', '\x20.CurrentScore', '#phone-wrapper', 'You\x20can\x20ask\x20me\x20any\x20query\x20regarding\x20', 'getHours', 'मैं\x20आपके\x20द्वारा\x20पूछे\x20गए\x20शब्दों\x20को\x20समझ\x20नहीं\x20पा\x20रही\x20हूँ\x20।', '#nicci_nav\x20.nav-link', 'Portal\x20is\x20not\x20enabled\x20for\x20Hindi\x20language.', 'keys', '<i\x20class=\x22fa\x20fa-info-circle\x22\x20aria-hidden=\x22true\x22\x20style=\x22color:\x20white;\x22></i>&nbsp;\x20Reached\x20maximumn\x20characters\x20limit\x20!!', '\x20दिनांक\x20है', '</ul><span\x20class=\x22hln\x22><a\x20onclick=\x22postBotReply([\x27', '\x27]);\x22><b>Helpline\x20Number</b></a></span></div>', 'Chrome', '3370360pKeEin', 'मैं\x20आपकी\x20', '#back-button', 'उपयोगकर्ता\x20चैट\x20इंटरफेस\x20या\x20आवाज\x20के\x20माध्यम\x20से\x20चैटबोट\x20के\x20साथ\x20संवाद\x20करते\x20हैं,\x20जैसे\x20कि\x20उपयोगकर्ता\x20किसी\x20वास्तविक\x20व्यक्ति\x20से\x20बात\x20करता\x20हैं', 'nicciFeebackbox', 'मैं\x20एआई\x20आधारित\x20एक\x20चैटबॉट\x20हूँ', 'Mozilla', '1183810IzCVSz', 'या\x20नीचे\x20सुझाए\x20गए\x20प्रश्नों\x20में\x20से\x20किसी\x20एक\x20का\x20चयन\x20करे\x20:</span><ul\x20style=\x22padding-left:\x2023px\x20!important;float:left\x20!important;\x22>', '2-digit', 'removeAttr', 'RequestedKeyWords', 'Saturday', '<li\x20class=\x22niccitag\x22\x20onclick=\x22$(\x27#message\x27).html(\x27', 'pitch', '.NiccifbMsg', 'Maybe\x20I\x20did\x20not\x20understand\x20you\x20properly.', '\x20Feel\x20free\x20to\x20ask\x20as\x20much\x20as\x20you\x20want', '#Niccisearchcontent', 'Sometimes\x20I\x20may\x20not\x20have\x20the\x20information\x20you\x20need.', '\x22,\x22inhindi\x22:\x22', 'StyleMedia', '</b>', 'stringify', '/chatbotService.asmx/GetBotResponse', '\x22,\x22searchType\x22:\x20\x22', 'safari', 'niccciblink', 'addons', '</ul><span\x20class=\x22hln\x22\x20style=\x27display:none;\x27><a\x20onclick=\x22postBotReply([\x27', 'मैं\x20आपकी\x20किस\x20प्रकार\x20से\x20सहायता\x20कर\x20सकती\x20हूँ', 'ResponseKeyWords', 'prevUntil', 'चैटबॉट\x20या\x20बॉट\x20-\x20एक\x20कंप्यूटर\x20प्रोग्राम\x20है\x20जो\x20एक\x20वास्तविक\x20मनुष्य\x20से\x20वार्तालाप\x20का\x20अनुकरण\x20करता\x20है।', 'border', '\x20वर्तमान\x20माह\x20', 'नमस्कार', 'July', '9926896efDDOt', 'en-US', '\x20Current\x20month\x20is\x20', 'दिसंबर', '#Nicci_feedback', '<i\x20data-toggle=\x22tooltip\x22\x20title=\x22click\x20to\x20listen\x20sound\x22\x20class=\x22fa\x20fa-volume-off\x22\x20aria-hidden=\x22true\x22\x20style=\x22font-size:\x2020px;\x20cursor:pointer;\x22\x20aria-hidden=\x22true\x22></i>', 'blur', 'Would\x20you\x20please\x20fine\x20tune\x20your\x20query\x20for\x20me\x20to\x20understand\x20better.', ':KW:', 'test', '#Nicci_errorMsg', 'mouseleave', 'play', 'DisplayContent', 'Safari', 'attr', 'January', '#nicciremainingC', 'जी\x20हाँ\x20।', 'nicci-outline', 'keyCode', '#emoijis', 'setDate', 'currentTarget', 'कभी-कभी\x20मेरे\x20पास\x20आपकी\x20द्वारा\x20पूछी\x20गयी\x20आवश्यक\x20जानकारी\x20नहीं\x20हो\x20सकती\x20है\x20।', '.fa-info-circle', 'show', '#nav-icon_nicci', 'true', 'मैं\x20आपके\x20द्वारा\x20पूछे\x20गए\x20प्रश्न\x20को\x20समझ\x20नहीं\x20पा\x20रही\x20हूँ\x20।', '#ctl01_closebtn', 'documentMode', '1015242Tqayzt', '#suggestionlist\x20li', 'अगस्त', 'innerLangDiv', 'मेरा\x20नाम\x20निक्की\x20है', 'getMonth', 'Please\x20give\x20star\x20rating\x20!!', '6402255LVJaxR', '</ul></div>', '#nav-container1', 'Chatbot\x20or\x20bot\x20–\x20is\x20a\x20computer\x20program\x20that\x20simulates\x20a\x20natural\x20human\x20conversation.', 'Choose\x20Hindi', 'Sorry\x20you\x20didn\x27t\x20tell\x20me\x20your\x20name.', '<li\x20class=\x22kwm\x22\x20><a\x20style=\x22color:#0008ff\x20!important;\x22\x20onclick=\x22$(\x27.tags\x20li.kwl\x27).fadeIn(1500);$(\x27.tags\x20span.hln\x27).fadeIn(2500);$(this).parent().hide();$scrollDown();\x22>more\x20...</a></li>', 'css', '\x20OPR/', '\x20से\x20संबंधित\x20किसी\x20भी\x20जानकारी\x20के\x20लिए\x20आपकी\x20डिजिटल\x20असिस्टेंट\x20।', 'message', 'filter', 'exec', '\x27);\x20$postMessage();\x22>', 'शायद\x20मैं\x20आपके\x20प्रश्न\x20को\x20ठीक\x20से\x20समझ\x20नहीं\x20पायी\x20।', 'removeClass', 'toString', 'html', '#emoi', 'indexOf', 'json', '.fa-refresh', ');\x22>', 'fadeIn', '#Nicci_fberrorMsg', 'CSS', 'name', 'Sorry\x20to\x20hear,\x20How\x20Can\x20I\x20help\x20You', 'contentEditable', 'Good\x20Night', 'क्षमा\x20करें\x20आपने\x20मुझे\x20अपना\x20नाम\x20नहीं\x20बताया।', '<i\x20class=\x22fa\x20fa-info-circle\x22\x20aria-hidden=\x22true\x22\x20style=\x22color:\x20white;\x22></i>&nbsp;\x20Please\x20enter\x20complete\x20query\x20(Min.\x204\x20characters)', 'September', '#message', 'getMinutes', 'getSeconds', '\x22,\x22name\x22:\x20\x22', '\x22,\x22inhindi\x22:\x20\x22', '\x20Today\x20is\x20', 'हिन्दी\x20लिखने\x20के\x20लिए\x20Alt+Shift\x20दबाये\x20।', '<span\x20class=\x22timestamp\x22>', '\x27\x20target=\x27_blank\x27>', '#chatAudio', '#username', 'getDate', 'outerLangDiv', '</span>', 'slow', 'जनवरी', 'कृपया\x20नीचे\x20सुझाए\x20गए\x20प्रश्नों\x20में\x20से\x20किसी\x20एक\x20का\x20चयन\x20करे\x20:', 'focus', 'अक्टूबर', 'कृपया\x20शब्दों\x20का\x20चयन\x20ध्यान\x20से\x20करे\x20और\x20पुनः\x20प्रयास\x20करें\x20।', 'कृपया\x20', 'Wednesday', '\x20पोर्टल\x20हेल्पलाइन\x20नंबर\x20पर\x20संपर्क\x20करें\x20।', 'trim', 'Nicci_fberrorMsg', '\x20से\x20संबन्धित\x20कोई\x20भी\x20प्रश्न\x20पूछ\x20सकते\x20हैं', '<i\x20class=\x22fa\x20fa-info-circle\x22\x20aria-hidden=\x22true\x22\x20style=\x22color:\x20white;\x22></i>&nbsp;\x20Please\x20enter\x20correct\x20Name\x20!!', 'getFullYear', 'opera', 'Blink', 'toggleClass', 'scrollHeight', '\x20हैं', '1000', 'शुक्रवार', 'कृपया\x20पुन:\x20प्रयास\x20करें\x20।', 'आपका\x20स्वागत\x20हैं\x20', 'rating', 'Maximum\x20characters:\x20180', '\x20आज\x20', 'You\x27re\x20welcome\x20', 'removeProp', 'object', 'August', '\x5c$&', 'none', 'err', 'checked', 'length', 'मैं\x20ठीक\x20हूँ,\x20धन्यवाद', '\x20is\x20current\x20time.', 'My\x20name\x20is\x20Nicci', '\x22,\x22rating\x22:\x22', '/chatbotService.asmx/GetBotSuggestions', 'random', 'Nicci_errorMsg01', '#ndhp', 'toLocaleTimeString', 'substring', 'append', '148898vtrXxz', 'Google\x20हिन्दी', '\x20वर्तमान\x20वित्तीय\x20वर्ष\x20', 'Your\x20words\x20are\x20not\x20making\x20sense\x20to\x20me.', 'string', 'undefined', ',\x20Please\x20chat\x20in\x20Hindi\x20language\x20now.', 'Microsoft\x20Zira\x20-\x20English\x20(United\x20States)', 'March', 'गुरुवार', '<div\x20class=\x22tags\x22><span>', '#start-chat', 'select', 'getVoices', 'शुभप्रभात', '/chatbotService.asmx/BotReply', 'रविवार', 'Thursday', 'May', '.tooltiptext', 'POST', 'hide', '<br>', '\x20Helpline\x20Number.', 'keyup', '</div></div>', '{\x22pId\x22:\x22', '</b></li><li>', '<li\x20class=\x22kwl\x22\x20style=\x22display:none;\x22><a\x20onclick=\x22$(\x27#message\x27).html(\x27', 'getDay', '#loadingimg', 'cancel', '.nicci-rating-star-block\x20.nicci-star', 'find', 'text', 'कृपया\x20अपना\x20प्रश्न\x20पुनः\x20लिखें\x20या\x20अपनी\x20पूरी\x20क्वेरी\x20टाइप\x20करें\x20।', 'Google\x20UK\x20English\x20Female', '1px\x20solid\x20red', '\x22,\x22authtoken\x22:\x20\x22', '{\x22matchedPattern\x22:\x22', 'nicci-filled', 'charCode', '.icondiv', '</a>', '2226240nTMSMJ', 'I\x20would\x20like\x20to\x20assist\x20you', 'slideDown', 'delay', '#Nicci_voiceMsg', 'Rs.', 'Start\x20a\x20conversation', 'speechSynthesis', 'June', 'split', 'webstore', 'फ़रवरी', 'This\x20is\x20NICCI,\x20your\x20digital\x20assistant\x20for\x20any\x20query\x20related\x20to\x20', 'Sunday', 'username', '(?:^|\x5cs)[', 'I\x20am\x20Fine,\x20Thankyou', '<i\x20class=\x22fa\x20fa-angle-down\x22\x20aria-hidden=\x22true\x22></i>', '<div\x20style=\x22display:flex;\x22><div><img\x20alt=\x22\x22\x20src=', '#ctl01_landing', '33qKBGIS', '#nicciFBClose', 'fa-lg', '\x20or\x20', '<li\x20class=\x22kwm\x22\x20><a\x20style=\x22color:#0008ff\x20!important;\x22\x20onclick=\x22$(\x27.tags\x20li.kwl\x27).fadeIn(1500);$(this).parent().hide();$scrollDown();\x22>more\x20...</a></li></ul></div>', '/chatbotService.asmx/SearchResponse', 'fa-info-circle', 'Friday', '<div\x20style=\x22display:flex;justify-content:\x20flex-end;\x22><div\x20class=\x22post\x20post-bot\x22\x20id=\x27', 'मैं\x20निक्की,\x20', 'push', 'Your\x20digital\x20assistant\x20for\x20any\x20query\x20related\x20to\x20', 'Please\x20\x20choose\x20one\x20of\x20the\x20below\x20suggested\x20questions:', 'join', 'जून', '#ctl01_landDiv', '\x27);tagSend(', '{\x22authtoken\x22:\x22', 'Edge', 'Users\x20communicate\x20with\x20a\x20chatbot\x20via\x20the\x20chat\x20interface\x20or\x20by\x20voice,\x20like\x20how\x20they\x20would\x20talk\x20to\x20a\x20real\x20person.', '<i\x20class=\x22fa\x20fa-info-circle\x22\x20aria-hidden=\x22true\x22\x20style=\x22color:\x20white;\x22></i>&nbsp;\x20Special\x20characters\x20are\x20not\x20allowed', '</ul>', 'I\x20am\x20AI\x20based\x20Voice\x20Enabled\x20Chatbot', 'parse', 'application/json;\x20charset=utf-8', 'slideToggle', 'volume', 'हिंदी\x20में\x20बात\x20कर\x20सकते\x20है', 'preventDefault', 'data-placeholder', '#nicciFBBtn', '<div\x20class=\x22niccitgd\x22><ul\x20class=\x22niccitags\x22>', 'disabled', 'December', '</div><div><img\x20alt=\x22\x22\x20src=', 'runtime', 'नवंबर', 'कृपया\x20दिये\x20गए\x20लिंक\x20पर\x20जाए\x20<br/><a\x20class=\x22niccitag_a\x22\x20href=\x27', 'prop', 'remove', '#Niccisearchslide', '#clear-history', '\x20is\x20tommarow\x20date.', 'Monday', 'floor', 'clone', 'replace', 'अप्रैल', 'false', 'Nicci_errorMsg', 'Start', 'Please\x20chat\x20in\x20Hindi\x20language\x20now.', '#message-board', 'ajax', 'Microsoft\x20Zira\x20Desktop\x20-\x20English\x20(United\x20States)', 'Microsoft\x20Kalpana\x20-\x20Hindi\x20(India)', 'slideUp', '</a></li>', 'शुभरात्रि', 'Please\x20contact\x20', 'fa-refresh\x20fa-spin', 'title', 'Rate\x20Us', '<i\x20data-toggle=\x22tooltip\x22\x20title=\x22click\x20to\x20mute\x20sound\x22\x20class=\x22fa\x20fa-volume-up\x22\x20aria-hidden=\x22true\x22\x20style=\x22font-size:\x2020px;\x20cursor:pointer;\x22\x20aria-hidden=\x22true\x22></i>', 'ContentType', 'lang', '#ctl01_chkLang', 'Good\x20Morning', 'each', '#nicciFeebackbox', 'fa\x20fa-grin\x20far\x20fa-chevron-down'];
    _0x1ae3 = function() {
        return _0x4908b8;
    };
    return _0x1ae3();
}

function getRootWebSitePath() {
    return _rootPath;
}

function getsuggestion(_0x96f981, _0x50d578) {
    var _0x48cac8 = _0xb72139,
        _0x32f084 = _0x96f981[_0x48cac8(0x266)] == 0x0 ? _0x96f981[_0x48cac8(0x2ff)] : _0x96f981[_0x48cac8(0x266)];
    if (_0x32f084 == 0x0 || _0x32f084 == 0xe5) _0x32f084 = getAndroidKeyCode($(_0x50d578)['text']());
    if (_0x32f084 == 0xd || _0x32f084 == 0x20 || _0x32f084 == 0x8 || _0x32f084 == 0x2e) {
        $(_0x48cac8(0x205))[_0x48cac8(0x28a)]('');
        var _0x30808d = $(_0x50d578)['text']();
        $[_0x48cac8(0x1d3)]({
            'type': _0x48cac8(0x2ea),
            'url': getRootWebSitePath() + _0x48cac8(0x2cf),
            'data': _0x48cac8(0x1f5) + _0x30808d + _0x48cac8(0x2fc) + $(_0x48cac8(0x1f2))['val']() + _0x48cac8(0x29e) + lang_Hindi + '\x22}',
            'contentType': _0x48cac8(0x32e),
            'dataType': 'json',
            'async': ![],
            'success': function(_0x3de118) {
                var _0x4ab53e = _0x48cac8;
                try {
                    var _0x1676f7 = JSON[_0x4ab53e(0x32d)](_0x3de118['d']);
                    _0x1676f7[_0x4ab53e(0x2ca)] > 0x0 && ($(_0x1676f7)['each'](function(_0x455bdc, _0x2a3c1e) {
                        var _0x1ec57d = _0x4ab53e;
                        $(_0x1ec57d(0x205))[_0x1ec57d(0x2d5)]($(document[_0x1ec57d(0x20e)]('li'))[_0x1ec57d(0x2f8)](_0x2a3c1e[_0x1ec57d(0x237)]));
                    }), $(_0x4ab53e(0x273))[_0x4ab53e(0x208)](function() {
                        var _0x5a63bd = _0x4ab53e;
                        $(_0x5a63bd(0x29a))[_0x5a63bd(0x28a)]($(this)[_0x5a63bd(0x28a)]()), $postMessage(), $(_0x5a63bd(0x205))[_0x5a63bd(0x28a)](''), $(_0x5a63bd(0x29a))[_0x5a63bd(0x2ab)]();
                    }));
                } catch (_0x408bf0) {}
            },
            'failure': function(_0x3a4562) {},
            'error': function(_0x18c8dc) {}
        });
    }
}
var getAndroidKeyCode = function(_0x58b833) {
    var _0x3d9a12 = _0xb72139;
    return _0x58b833[_0x3d9a12(0x20f)](_0x58b833[_0x3d9a12(0x2ca)] - 0x1);
};

function loadVoices() {
    var _0x4c7c07 = _0xb72139,
        _0x3c2c7c = speechSynthesis[_0x4c7c07(0x2e3)]();
}
loadVoices(), window[_0xb72139(0x309)][_0xb72139(0x210)] = function(_0x34b213) {
    loadVoices();
};

function checkSpeakStatus() {
    var _0x32ad71 = _0xb72139;
    if (_0x32ad71(0x309) in window) {} else $(_0x32ad71(0x1fd))[_0x32ad71(0x2eb)]();
}
checkSpeakStatus();

function speechInit() {
    var _0x41282e = _0xb72139;
    msg = new SpeechSynthesisUtterance(), msg[_0x41282e(0x330)] = 0x1, msg[_0x41282e(0x1ee)] = 0x1, msg['pitch'] = 0x1;
    var _0x345f31 = speechSynthesis[_0x41282e(0x2e3)]()[_0x41282e(0x284)](function(_0x31eb3b) {
        return _0x31eb3b['name'] == 'Microsoft\x20Anna\x20-\x20English\x20(United\x20States)';
    })[_0x41282e(0x2ca)];
    if (_0x345f31 == '0') {
        var _0x5ec17c = speechSynthesis[_0x41282e(0x2e3)]()[_0x41282e(0x284)](function(_0x256241) {
            var _0x35503b = _0x41282e;
            return _0x256241[_0x35503b(0x293)] == _0x35503b(0x2fa);
        })[_0x41282e(0x2ca)];
        if (_0x5ec17c == '0') {
            var _0xe6ee51 = speechSynthesis[_0x41282e(0x2e3)]()[_0x41282e(0x284)](function(_0x190ee1) {
                var _0x173261 = _0x41282e;
                return _0x190ee1[_0x173261(0x293)] == _0x173261(0x1d4);
            })[_0x41282e(0x2ca)];
            if (_0xe6ee51 == '0') msg[_0x41282e(0x216)] = speechSynthesis[_0x41282e(0x2e3)]()[_0x41282e(0x284)](function(_0x33d9fc) {
                var _0x41a237 = _0x41282e;
                return _0x33d9fc[_0x41a237(0x293)] == _0x41a237(0x2dd);
            })[0x0];
            else msg[_0x41282e(0x216)] = speechSynthesis['getVoices']()[_0x41282e(0x284)](function(_0x5e0782) {
                var _0xd4b6d1 = _0x41282e;
                return _0x5e0782['name'] == _0xd4b6d1(0x1d4);
            })[0x0];
        } else msg[_0x41282e(0x216)] = speechSynthesis['getVoices']()[_0x41282e(0x284)](function(_0x1b7f6c) {
            var _0x21f397 = _0x41282e;
            return _0x1b7f6c[_0x21f397(0x293)] == _0x21f397(0x2fa);
        })[0x0];
    } else msg[_0x41282e(0x216)] = speechSynthesis['getVoices']()['filter'](function(_0x2a5462) {
        var _0x2fb94d = _0x41282e;
        return _0x2a5462[_0x2fb94d(0x293)] == 'Microsoft\x20Anna\x20-\x20English\x20(United\x20States)';
    })[0x0];
}

function speak(_0x3be9c7) {
    var _0x3b951c = _0xb72139;
    msg = new SpeechSynthesisUtterance(), msg[_0x3b951c(0x2f8)] = _0x3be9c7, msg[_0x3b951c(0x330)] = 0x1, msg[_0x3b951c(0x1ee)] = 0x1, msg[_0x3b951c(0x23a)] = 0x1;
    if (!lang_Hindi) {
        $(_0x3b951c(0x306))[_0x3b951c(0x2eb)](0x3e8);
        var _0x239c89 = speechSynthesis[_0x3b951c(0x2e3)]()['filter'](function(_0x49a322) {
            var _0x4841ab = _0x3b951c;
            return _0x49a322['name'] == _0x4841ab(0x2dd);
        })[_0x3b951c(0x2ca)];
        if (_0x239c89 == '0') {
            var _0x1a743e = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x7db2c2) {
                var _0x48764e = _0x3b951c;
                return _0x7db2c2['name'] == _0x48764e(0x2fa);
            })[_0x3b951c(0x2ca)];
            if (_0x1a743e == '0') {
                var _0x1b8784 = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x4389b9) {
                    var _0x3680ac = _0x3b951c;
                    return _0x4389b9[_0x3680ac(0x293)] == _0x3680ac(0x2dd);
                })[_0x3b951c(0x2ca)];
                if (_0x1b8784 == '0') msg[_0x3b951c(0x216)] = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x2b4b46) {
                    var _0x4b8944 = _0x3b951c;
                    return _0x2b4b46['name'] == _0x4b8944(0x2dd);
                })[0x0];
                else msg[_0x3b951c(0x216)] = speechSynthesis['getVoices']()['filter'](function(_0x4a24a1) {
                    var _0x42232d = _0x3b951c;
                    return _0x4a24a1[_0x42232d(0x293)] == _0x42232d(0x2dd);
                })[0x0];
            } else msg['voice'] = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x19ba7e) {
                var _0x5b083e = _0x3b951c;
                return _0x19ba7e[_0x5b083e(0x293)] == _0x5b083e(0x2fa);
            })[0x0];
        } else msg['voice'] = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x2abb37) {
            var _0x171cd3 = _0x3b951c;
            return _0x2abb37[_0x171cd3(0x293)] == _0x171cd3(0x2dd);
        })[0x0];
    } else {
        var _0x5de74a = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x13fc15) {
            var _0x3f0a05 = _0x3b951c;
            return _0x13fc15[_0x3f0a05(0x293)] == _0x3f0a05(0x1d5);
        })['length'];
        if (_0x5de74a == '0') {
            var _0x507a2e = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x33b079) {
                var _0x325a13 = _0x3b951c;
                return _0x33b079[_0x325a13(0x293)] == _0x325a13(0x2d7);
            })[_0x3b951c(0x2ca)];
            _0x507a2e == '0' ? ($('#Nicci_voiceMsg')[_0x3b951c(0x290)](0x3e8), window['speechSynthesis']['cancel']()) : msg['voice'] = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x4701d5) {
                var _0x38c02d = _0x3b951c;
                return _0x4701d5['name'] == _0x38c02d(0x2d7);
            })[0x0];
        } else msg[_0x3b951c(0x216)] = speechSynthesis[_0x3b951c(0x2e3)]()[_0x3b951c(0x284)](function(_0x186495) {
            var _0xc4b6bf = _0x3b951c;
            return _0x186495[_0xc4b6bf(0x293)] == 'Microsoft\x20Kalpana\x20-\x20Hindi\x20(India)';
        })[0x0];
    }
    window['speechSynthesis']['speak'](msg);
}

function mutevoice(_0x2e475c) {
    var _0x12b9e3 = _0xb72139,
        _0x302c57 = $(_0x2e475c)[_0x12b9e3(0x28a)]();
    $(_0x2e475c)[_0x12b9e3(0x2f8)]('');
    var _0x3cd919 = '';
    if (/fa-volume-off/ [_0x12b9e3(0x25b)](_0x302c57)) window['speechSynthesis'][_0x12b9e3(0x2f5)](), _0x3cd919 = '<span\x20class=\x22fa\x20fa-volume-up\x22\x20aria-hidden=\x22true\x22></span>Unmute\x20Voice', isVoicemute = !![];
    else /fa-volume-up/ ['test'](_0x302c57) && (_0x3cd919 = '<span\x20class=\x22fa\x20fa-volume-off\x22\x20aria-hidden=\x22true\x22></span>Mute\x20Voice', isVoicemute = ![]);
    $(_0x2e475c)[_0x12b9e3(0x28a)](_0x3cd919);
}

function mutevoice2(_0x31419e) {
    var _0x466c0b = _0xb72139,
        _0x251197 = $(_0x31419e)[_0x466c0b(0x28a)]();
    $(_0x31419e)[_0x466c0b(0x2f8)]('');
    var _0x42712b = '';
    if (/fa-volume-up/ [_0x466c0b(0x25b)](_0x251197)) window[_0x466c0b(0x309)][_0x466c0b(0x2f5)](), _0x42712b = _0x466c0b(0x257), isVoicemute = !![];
    else /fa-volume-off/ ['test'](_0x251197) && (_0x42712b = _0x466c0b(0x1dd), isVoicemute = ![]);
    $(_0x31419e)[_0x466c0b(0x28a)](_0x42712b);
}

function escapeRegExp(_0x48cfd5) {
    var _0x1981c7 = _0xb72139;
    return _0x48cfd5[_0x1981c7(0x1cc)](/[.*+?^${}()|[\]\\]/g, _0x1981c7(0x2c6));
}

function replaceAll(_0x515937, _0x32e623, _0x5d78c1) {
    var _0xef8b1c = _0xb72139;
    return _0x515937[_0xef8b1c(0x1cc)](new RegExp(escapeRegExp(_0x32e623), 'g'), _0x5d78c1);
}

function getBrowserType() {
    var _0xd4f2ac = _0xb72139,
        _0x455418 = '',
        _0x1ef6fd = !!window['opr'] && !!opr[_0xd4f2ac(0x248)] || !!window[_0xd4f2ac(0x2b6)] || navigator[_0xd4f2ac(0x1e7)][_0xd4f2ac(0x28c)](_0xd4f2ac(0x281)) >= 0x0,
        _0x4b5055 = typeof InstallTrigger !== _0xd4f2ac(0x2db),
        _0x118e8b = /constructor/i [_0xd4f2ac(0x25b)](window['HTMLElement']) || function(_0x52d1d0) {
            var _0x392b1f = _0xd4f2ac;
            return _0x52d1d0[_0x392b1f(0x289)]() === _0x392b1f(0x20d);
        }(!window[_0xd4f2ac(0x246)] || typeof safari !== 'undefined' && safari['pushNotification']),
        _0x2eee30 = ![] || !!document[_0xd4f2ac(0x271)],
        _0x59c2fe = !_0x2eee30 && !!window[_0xd4f2ac(0x241)],
        _0x4f65a9 = !!window[_0xd4f2ac(0x218)] && (!!window[_0xd4f2ac(0x218)][_0xd4f2ac(0x30c)] || !!window[_0xd4f2ac(0x218)][_0xd4f2ac(0x1c1)]),
        _0x1d637e = (_0x4f65a9 || _0x1ef6fd) && !!window[_0xd4f2ac(0x292)];
    if (_0x4b5055) _0x455418 = 'Mozilla';
    else {
        if (_0x4f65a9) _0x455418 = _0xd4f2ac(0x22b);
        else {
            if (_0x118e8b) _0x455418 = _0xd4f2ac(0x260);
            else {
                if (_0x1ef6fd) _0x455418 = _0xd4f2ac(0x206);
                else {
                    if (_0x2eee30) _0x455418 = 'IE';
                    else {
                        if (_0x59c2fe) _0x455418 = _0xd4f2ac(0x328);
                        else {
                            if (_0x1d637e) _0x455418 = _0xd4f2ac(0x2b7);
                        }
                    }
                }
            }
        }
    }
    return _0x455418;
}

function getTimeSalutation() {
    var _0xe7a3ab = _0xb72139,
        _0x5b6ed5 = new Date(),
        _0x54d953 = _0x5b6ed5[_0xe7a3ab(0x222)](),
        _0x2f1cb5 = '';
    if (!lang_Hindi) _0x2f1cb5 = _0x54d953 < 0xc ? _0xe7a3ab(0x1e1) : _0x54d953 < 0x11 ? 'Good\x20Afternoon' : _0x54d953 < 0x14 ? 'Good\x20Evening' : _0xe7a3ab(0x296);
    else _0x2f1cb5 = _0x54d953 < 0xc ? _0xe7a3ab(0x2e4) : _0x54d953 < 0x11 ? 'नमस्कार' : _0x54d953 < 0x14 ? _0xe7a3ab(0x250) : _0xe7a3ab(0x1d8);
    return _0x2f1cb5;
}
var _isClicked = ![],
    _count = 0x1;
$('.nicci-rating-star-block\x20.nicci-star')[_0xb72139(0x25d)](function() {
    var _0x2e10f5 = _0xb72139;
    !_isClicked ? $('#' + $(this)['parent']()[_0x2e10f5(0x21e)]()['attr']('id') + '\x20.nicci-star')[_0x2e10f5(0x1e2)](function() {
        var _0x2fff2d = _0x2e10f5;
        $(this)[_0x2fff2d(0x1f6)](_0x2fff2d(0x265)), $(this)['removeClass'](_0x2fff2d(0x2fe));
    }) : (_count = 0x1, $('#' + $(this)[_0x2e10f5(0x21e)]()[_0x2e10f5(0x21e)]()[_0x2e10f5(0x261)]('id') + '\x20.nicci-star')['each'](function() {
        var _0x1d0f72 = _0x2e10f5;
        if (_count <= parseInt(starRating)) $(this)[_0x1d0f72(0x1f6)](_0x1d0f72(0x2fe));
        else $(this)[_0x1d0f72(0x1f6)](_0x1d0f72(0x265)), $(this)['removeClass'](_0x1d0f72(0x2fe));
        _count++;
    }));
}), $(_0xb72139(0x2f6))['mouseenter'](function() {
    var _0x170c26 = _0xb72139,
        _0x393ea9 = $(this)[_0x170c26(0x261)](_0x170c26(0x2bf));
    $(this)[_0x170c26(0x24c)]()[_0x170c26(0x1f6)](_0x170c26(0x2fe)), $(this)[_0x170c26(0x1f6)](_0x170c26(0x2fe)), $('#RAT')[_0x170c26(0x28a)](_0x393ea9);
}), $('.nicci-rating-star-block\x20.nicci-star')[_0xb72139(0x208)](function() {
    var _0x4bcd03 = _0xb72139,
        _0x1f9629 = $(this)[_0x4bcd03(0x261)](_0x4bcd03(0x2bf));
    return starRating = _0x1f9629, _isClicked = !![], _count = 0x1, $('#' + $(this)[_0x4bcd03(0x21e)]()[_0x4bcd03(0x21e)]()[_0x4bcd03(0x261)]('id') + _0x4bcd03(0x1f0))[_0x4bcd03(0x1e2)](function() {
        var _0x2135e6 = _0x4bcd03;
        if (_count <= parseInt(_0x1f9629)) $(this)[_0x2135e6(0x1f6)](_0x2135e6(0x2fe));
        else $(this)[_0x2135e6(0x288)]('nicci-filled');
        _count++;
    }), $(_0x4bcd03(0x1e3))['focus'](), ![];
});

function sendfeedbk() {
    var _0x873484 = _0xb72139,
        _0x3d04aa = 0x0,
        _0x54912e = '#' + $(this)[_0x873484(0x21e)]()[_0x873484(0x21e)]()[_0x873484(0x261)]('id') + _0x873484(0x21f),
        _0x5414bb = $(_0x873484(0x1e3))[_0x873484(0x203)]()[_0x873484(0x2b1)]();
    if (starRating == 0x0) return $(_0x873484(0x291))[_0x873484(0x28a)](_0x873484(0x278)), $(_0x873484(0x291))[_0x873484(0x304)](0xc8), setTimeout(function() {
        var _0x4be521 = _0x873484;
        $(_0x4be521(0x291))[_0x4be521(0x1d6)](0x1f4);
    }, 0x7d0), ![];
    if (!lang_Hindi) {
        if (!(checkSymbols('nicciFeebackbox', _0x873484(0x2b2)) && checkRestrictedWords(_0x873484(0x230), _0x873484(0x2b2)))) return ![];
    } else {
        if (!checkRestrictedWords('nicciFeebackbox', _0x873484(0x2b2))) return ![];
    }
    $['ajax']({
        'type': 'POST',
        'url': getRootWebSitePath() + '/chatbotService.asmx/nicci_feedback',
        'data': '{\x22authtoken\x22:\x20\x22' + $('#ctl01_hdnToken')['val']() + _0x873484(0x29d) + $userName + '\x22,\x22feedback\x22:\x22' + _0x5414bb + _0x873484(0x2ce) + starRating + _0x873484(0x240) + lang_Hindi + '\x22}',
        'contentType': _0x873484(0x32e),
        'dataType': _0x873484(0x28d),
        'async': ![],
        'success': function(_0x5ca390) {
            var _0x14907b = _0x873484;
            $(_0x14907b(0x1e3))['hide'](), $('#nicciFBBtn')[_0x14907b(0x2eb)](), $('#nicciSkipBtn')[_0x14907b(0x2eb)](), $(_0x14907b(0x317))['hide'](), $(_0x14907b(0x1e9))[_0x14907b(0x2eb)](), $(_0x14907b(0x263))['hide'](), $(_0x14907b(0x291))[_0x14907b(0x28a)](_0x14907b(0x32a)), setNewScore(_0x54912e, _0x5ca390['d']);
        },
        'error': function(_0x5bc069) {}
    });
}

function setNewScore(_0x21e564, _0x3e7653) {
    var _0x57375b = _0xb72139;
    $('.NiccifbMsg')['html']('<b\x20style=\x27color:#ff9900;\x20font-size:20px\x27>' + _0x3e7653 + _0x57375b(0x242)), setTimeout(function() {
        var _0x2f5990 = _0x57375b;
        $('#Nicci_feedback')[_0x2f5990(0x2eb)](), nicciExitCode();
    }, 0x7d0);
}

function skipfeedbk() {
    setTimeout(function() {
        var _0x6d2903 = _0x4a3a;
        $('#Nicci_feedback')[_0x6d2903(0x2eb)](), nicciExitCode();
    }, 0x3e8);
}
$(_0xb72139(0x1e3))['keyup'](function() {
    var _0x14eaa4 = _0xb72139,
        _0x1973ac = 0x0,
        _0x2cb146 = 0xb4;
    _0x1973ac = this[_0x14eaa4(0x209)][_0x14eaa4(0x2ca)];
    if (_0x1973ac > _0x2cb146) return ![];
    else _0x1973ac > 0x0 ? $(_0x14eaa4(0x263))[_0x14eaa4(0x28a)](_0x14eaa4(0x213) + (_0x2cb146 - _0x1973ac)) : $(_0x14eaa4(0x263))[_0x14eaa4(0x28a)](_0x14eaa4(0x2c0));
});

function getFullDate() {
    var _0x56cd78 = _0xb72139,
        _0x420205 = date[_0x56cd78(0x2a5)](),
        _0x32ff7d = date[_0x56cd78(0x277)](),
        _0x5f2e00 = date[_0x56cd78(0x2b5)](),
        _0x3a1710, _0x224860;
    return !lang_Hindi ? _0x224860 = [_0x56cd78(0x262), 'February', 'March', _0x56cd78(0x1e8), _0x56cd78(0x2e8), 'June', _0x56cd78(0x251), _0x56cd78(0x2c5), 'September', _0x56cd78(0x21b), 'November', _0x56cd78(0x1bf)] : _0x224860 = [_0x56cd78(0x2a9), _0x56cd78(0x30d), _0x56cd78(0x214), _0x56cd78(0x1cd), 'मई', _0x56cd78(0x324), 'जुलाई', _0x56cd78(0x274), 'सितंबर', _0x56cd78(0x2ac), _0x56cd78(0x1c2), _0x56cd78(0x255)], _0x3a1710 = _0x420205[_0x56cd78(0x289)]() + '\x20' + _0x224860[_0x32ff7d] + '\x20' + _0x5f2e00[_0x56cd78(0x289)](), _0x3a1710;
}

function getTommarowDate() {
    var _0x31f233 = _0xb72139;
    const _0x26ce22 = new Date(),
        _0x40d911 = new Date(_0x26ce22);
    _0x40d911[_0x31f233(0x268)](_0x40d911[_0x31f233(0x2a5)]() + 0x1);
    var _0xab2909 = _0x40d911[_0x31f233(0x2a5)](),
        _0x3439bc = _0x40d911[_0x31f233(0x277)](),
        _0x35c9c3 = _0x40d911['getFullYear'](),
        _0x5576ca, _0x5ae944;
    return !lang_Hindi ? _0x5ae944 = ['January', 'February', _0x31f233(0x2de), _0x31f233(0x1e8), _0x31f233(0x2e8), _0x31f233(0x30a), _0x31f233(0x251), _0x31f233(0x2c5), _0x31f233(0x299), 'October', _0x31f233(0x217), _0x31f233(0x1bf)] : _0x5ae944 = ['जनवरी', 'फ़रवरी', _0x31f233(0x214), _0x31f233(0x1cd), 'मई', _0x31f233(0x324), 'जुलाई', _0x31f233(0x274), 'सितंबर', 'अक्टूबर', _0x31f233(0x1c2), _0x31f233(0x255)], _0x5576ca = _0xab2909[_0x31f233(0x289)]() + '\x20' + _0x5ae944[_0x3439bc] + '\x20' + _0x35c9c3[_0x31f233(0x289)](), _0x5576ca;
}

function getDayOfWeek() {
    var _0x368d6b = _0xb72139,
        _0x456015, _0x116c97;
    return !lang_Hindi ? (_0x116c97 = [_0x368d6b(0x30f), _0x368d6b(0x1c9), 'Tuesday', _0x368d6b(0x2af), _0x368d6b(0x2e7), _0x368d6b(0x31d), _0x368d6b(0x238)], _0x456015 = _0x116c97[date[_0x368d6b(0x2f3)]()]) : (_0x116c97 = [_0x368d6b(0x2e6), 'सोमवार', 'मंगलवार', _0x368d6b(0x1ed), _0x368d6b(0x2df), _0x368d6b(0x2bc), 'शनिवार'], _0x456015 = _0x116c97[date[_0x368d6b(0x2f3)]()]), _0x456015;
}

function getMonthOfYear() {
    var _0x41b511 = _0xb72139,
        _0x28241a, _0x18554f;
    return !lang_Hindi ? (_0x18554f = [_0x41b511(0x262), _0x41b511(0x21c), _0x41b511(0x2de), _0x41b511(0x1e8), _0x41b511(0x2e8), 'June', _0x41b511(0x251), _0x41b511(0x2c5), 'September', _0x41b511(0x21b), 'November', _0x41b511(0x1bf)], _0x28241a = _0x18554f[date[_0x41b511(0x277)]()]) : (_0x18554f = [_0x41b511(0x2a9), 'फ़रवरी', _0x41b511(0x214), 'अप्रैल', 'मई', _0x41b511(0x324), _0x41b511(0x202), 'अगस्त', 'सितंबर', _0x41b511(0x2ac), _0x41b511(0x1c2), _0x41b511(0x255)], _0x28241a = _0x18554f[date[_0x41b511(0x277)]()]), _0x28241a;
}
checkInputLength = function(_0x5de42e) {
    var _0x18958f = _0xb72139,
        _0x360bf4 = !![],
        _0x5d18e4 = 0x96;
    return _0x5de42e[_0x18958f(0x2b1)]()[_0x18958f(0x2ca)] >= _0x5d18e4 && (_0x360bf4 = ![], $('#message')[_0x18958f(0x305)](_0x18958f(0x2bb))[_0x18958f(0x280)](_0x18958f(0x24e), _0x18958f(0x2fb)), $(_0x18958f(0x25c))[_0x18958f(0x28a)](_0x18958f(0x227)), $(_0x18958f(0x25c))[_0x18958f(0x26c)](0x1f4), setTimeout(function() {
        var _0x3c00c2 = _0x18958f;
        $(_0x3c00c2(0x29a))[_0x3c00c2(0x305)](_0x3c00c2(0x2bb))['css'](_0x3c00c2(0x24e), 'none'), $('#Nicci_errorMsg')['hide'](0x1f4);
        var _0x3970a6 = _0x5de42e[_0x3c00c2(0x2b1)]()[_0x3c00c2(0x2d4)](0x0, _0x5d18e4);
        $(obj)['text'](_0x3970a6);
    }, 0xbb8)), _0x360bf4;
};

function checkLang(_0x131bc1) {
    var _0x166f6a = _0xb72139;
    if (_isBiLang[_0x166f6a(0x1ec)]() == _0x166f6a(0x26e)) {
        var _0x452eb3 = 0x80,
            _0x9a7db8 = 0x900,
            _0x8c0bf0 = [];
        for (var _0x1f3c30 = 0x0; _0x1f3c30 < _0x452eb3; _0x1f3c30++) {
            _0x8c0bf0[_0x166f6a(0x320)](_0x166f6a(0x219) + (_0x9a7db8 + _0x1f3c30)[_0x166f6a(0x289)](0x10));
        }
        var _0x2d2f90 = new RegExp(_0x166f6a(0x311) + _0x8c0bf0[_0x166f6a(0x323)]('') + _0x166f6a(0x1e5), 'g'),
            _0x1d1e0e = new RegExp('(?:^|\x5cs)[a-zA-Z0-9\x20]+?(?:\x5cs|$)', 'g');
        [_0x131bc1['match'](_0x2d2f90)]['forEach'](function(_0x496fc9) {
            var _0x42ec37 = _0x166f6a;
            if (_0x496fc9) {
                if (_0x1d1e0e[_0x42ec37(0x25b)](_0x131bc1)) return;
                else $(_0x42ec37(0x1e0))[_0x42ec37(0x1c4)](_0x42ec37(0x2c9), _0x42ec37(0x26e)), lang_Hindi = !![];
            } else $(_0x42ec37(0x1e0))[_0x42ec37(0x2c3)](_0x42ec37(0x2c9)), lang_Hindi = ![];
        });
    }
}

function getTags(_0x4fe6be) {
    var _0x16a7a6 = getRootWebSitePath();
    setTimeout(function() {
        var _0x1b4629 = _0x4a3a;
        $[_0x1b4629(0x1d3)]({
            'type': _0x1b4629(0x2ea),
            'url': _0x16a7a6 + _0x1b4629(0x20b),
            'data': _0x1b4629(0x2f0) + _0x4fe6be + _0x1b4629(0x2fc) + $(_0x1b4629(0x1f2))['val']() + _0x1b4629(0x29e) + lang_Hindi + '\x22}',
            'contentType': _0x1b4629(0x32e),
            'dataType': _0x1b4629(0x28d),
            'async': ![],
            'success': function(_0x550877) {
                var _0x386f36 = _0x1b4629,
                    _0x1be9e9 = JSON[_0x386f36(0x32d)](_0x550877['d']);
                if (_0x1be9e9[_0x386f36(0x2ca)] > 0x0) {
                    var _0x128e41 = _0x386f36(0x1bd);
                    for (var _0xcf2167 = 0x0; _0xcf2167 < _0x1be9e9[_0x386f36(0x2ca)]; _0xcf2167++) {
                        _0x128e41 += _0x386f36(0x239) + _0x1be9e9[_0xcf2167]['DisplayContent'] + _0x386f36(0x326) + _0x1be9e9[_0xcf2167]['Id'] + ',' + _0x1be9e9[_0xcf2167][_0x386f36(0x1de)][_0x386f36(0x2b1)]() + _0x386f36(0x28f) + _0x1be9e9[_0xcf2167][_0x386f36(0x25f)] + '</li>';
                    }
                    _0x128e41 += _0x386f36(0x27a), $(_0x386f36(0x1d2))[_0x386f36(0x2d5)](_0x128e41), setTimeout(function() {
                        var _0x3c5df5 = _0x386f36;
                        $(_0x3c5df5(0x2f4))[_0x3c5df5(0x2eb)](0xc8), document[_0x3c5df5(0x207)](_0x3c5df5(0x283))[_0x3c5df5(0x295)] = !![];
                    }, 0x32);
                } else setTimeout(function() {
                    var _0x930550 = _0x386f36;
                    $(_0x930550(0x2f4))[_0x930550(0x2eb)](), document[_0x930550(0x207)]('message')[_0x930550(0x295)] = !![];
                }, 0x32);
            },
            'failure': function(_0x530ba8) {},
            'error': function(_0x51298b) {}
        });
    }, 0x7d0);
}

function tagSend(_0x18cfd2, _0x2ef92c) {
    var _0x4b89b0 = _0xb72139;
    $(_0x4b89b0(0x29a))[_0x4b89b0(0x2f7)]('br')[_0x4b89b0(0x1c5)]();
    let _0x2fe844 = $(_0x4b89b0(0x29a))[_0x4b89b0(0x2f8)]()[_0x4b89b0(0x2b1)]();
    _0x2fe844 = _0x2fe844['replace'](/<div>/, _0x4b89b0(0x2ec))['replace'](/<div>/g, '')['replace'](/<\/div>/g, _0x4b89b0(0x2ec))[_0x4b89b0(0x1cc)](/<br>/g, '\x20')[_0x4b89b0(0x1cc)](/&nbsp;/g, '\x20')[_0x4b89b0(0x2b1)](), document[_0x4b89b0(0x207)](_0x4b89b0(0x283))[_0x4b89b0(0x295)] = ![];
    const _0x4d47c4 = _0x4b89b0(0x314) + getRootWebSitePath() + (_0x4b89b0(0x211) + (_0x2fe844 + timeStamp()) + '</div></div>');
    $('#message-board')[_0x4b89b0(0x2d5)](_0x4d47c4), $scrollDown(), $(_0x4b89b0(0x2f4))[_0x4b89b0(0x26c)](), setTimeout(function() {
        if (_0x2ef92c == '0') getTags(_0x18cfd2);
        else {
            if (_0x2ef92c == '1') getRsp(_0x18cfd2);
            else {
                if (_0x2ef92c == '2') getTC(_0x18cfd2, _0x2ef92c);
                else _0x2ef92c == '3' && getTC(_0x18cfd2, _0x2ef92c);
            }
        }
    }, 0x5dc), $(_0x4b89b0(0x205))['html'](''), $(_0x4b89b0(0x29a))[_0x4b89b0(0x1fe)](), noteContent = '', $scrollDown();
}

function getRsp(_0x5eca2b) {
    var _0x5786da = getRootWebSitePath();
    setTimeout(function() {
        var _0x19a07b = _0x4a3a;
        $[_0x19a07b(0x1d3)]({
            'type': _0x19a07b(0x2ea),
            'url': _0x5786da + _0x19a07b(0x2e5),
            'data': '{\x22tid\x22:\x22' + _0x5eca2b + '\x22,\x22authtoken\x22:\x20\x22' + $(_0x19a07b(0x1f2))[_0x19a07b(0x203)]() + _0x19a07b(0x29e) + lang_Hindi + '\x22}',
            'contentType': 'application/json;\x20charset=utf-8',
            'dataType': 'json',
            'async': ![],
            'success': function(_0x21962a) {
                var _0x13a612 = _0x19a07b,
                    _0x1e6911 = JSON['parse'](_0x21962a['d']);
                if (_0x1e6911[_0x13a612(0x2ca)] > 0x0) {
                    var _0x309a4d;
                    _0x1e6911[0x0]['ResponseKeyWords'][_0x13a612(0x2b1)]()['length'] > 0x0 && (_0x309a4d = _0x1e6911[0x0][_0x13a612(0x24b)][_0x13a612(0x30b)]('|'));
                    window[_0x13a612(0x309)][_0x13a612(0x2f5)]();
                    if (typeof _0x309a4d === _0x13a612(0x2da)) postBotReply(_0x309a4d);
                    else
                        for (var _0xdbff41 = 0x0; _0xdbff41 < _0x309a4d[_0x13a612(0x2ca)]; _0xdbff41++) {
                            (function(_0x3394ea) {
                                var _0x8beec5 = 0x7d0 * _0x3394ea;
                                setTimeout(function() {
                                    var _0x3e4f1b = _0x4a3a;
                                    if (_0x309a4d[_0x3394ea]['indexOf'](_0x3e4f1b(0x25a)) != -0x1) postBotKeywords(replaceAll(_0x309a4d[_0x3394ea], _0x3e4f1b(0x25a), ''));
                                    else postBotReply(_0x309a4d[_0x3394ea]);
                                    if (!isVoicemute) $(_0x3e4f1b(0x2a3))[0x0][_0x3e4f1b(0x25e)]();
                                }, _0x8beec5);
                            }(_0xdbff41));
                        }
                    setTimeout(function() {
                        var _0x438e62 = _0x13a612;
                        $(_0x438e62(0x2f4))[_0x438e62(0x2eb)](0xc8), document['getElementById'](_0x438e62(0x283))['contentEditable'] = !![], $(_0x438e62(0x2a3))[0x0][_0x438e62(0x25e)]();
                    }, 0x32);
                }
            },
            'failure': function(_0x34d8ac) {},
            'error': function(_0x1613e0) {}
        });
    }, 0x7d0);
}

function _0x4a3a(_0x1aface, _0x3ef18a) {
    var _0x1ae33c = _0x1ae3();
    return _0x4a3a = function(_0x4a3af5, _0x44ae5f) {
        _0x4a3af5 = _0x4a3af5 - 0x1bb;
        var _0x8dc383 = _0x1ae33c[_0x4a3af5];
        return _0x8dc383;
    }, _0x4a3a(_0x1aface, _0x3ef18a);
}

function getTC(_0x3465e, _0x48bc59) {
    var _0x4a0fbd = getRootWebSitePath();
    setTimeout(function() {
        var _0x33b5ef = _0x4a3a;
        $[_0x33b5ef(0x1d3)]({
            'type': _0x33b5ef(0x2ea),
            'url': _0x4a0fbd + '/chatbotService.asmx/getTC',
            'data': '{\x22pId\x22:\x22' + _0x3465e + _0x33b5ef(0x2fc) + $(_0x33b5ef(0x1f2))[_0x33b5ef(0x203)]() + _0x33b5ef(0x29e) + lang_Hindi + '\x22}',
            'contentType': _0x33b5ef(0x32e),
            'dataType': _0x33b5ef(0x28d),
            'async': ![],
            'success': function(_0x52e3df) {
                var _0xb3699 = _0x33b5ef,
                    _0x2e1325 = JSON[_0xb3699(0x32d)](_0x52e3df['d']);
                if (_0x2e1325[_0xb3699(0x2ca)] > 0x0) {
                    var _0x173b0a = '';
                    if (_0x48bc59 == '2')
                        for (var _0x529124 = 0x0; _0x529124 < _0x2e1325[_0xb3699(0x2ca)]; _0x529124++) {
                            if (!lang_Hindi) _0x173b0a += 'Please\x20refer\x20given\x20link\x20<br/><a\x20class=\x22niccitag_a\x22\x20href=\x27' + _0x2e1325[_0x529124][_0xb3699(0x1eb)] + '\x27\x20target=\x27_blank\x27>' + _0x2e1325[_0x529124][_0xb3699(0x1eb)][_0xb3699(0x2b1)]() + _0xb3699(0x301);
                            else _0x173b0a += _0xb3699(0x1c3) + _0x2e1325[_0x529124][_0xb3699(0x1eb)] + _0xb3699(0x2a2) + _0x2e1325[_0x529124][_0xb3699(0x1eb)][_0xb3699(0x2b1)]() + '</a>';
                        } else {
                            if (_0x48bc59 == '3') {
                                for (var _0x529124 = 0x0; _0x529124 < _0x2e1325[_0xb3699(0x2ca)]; _0x529124++) _0x173b0a += _0x2e1325[_0x529124][_0xb3699(0x1eb)];
                            }
                        }
                    postBotReply(_0x173b0a), setTimeout(function() {
                        var _0x293bd7 = _0xb3699;
                        $('#loadingimg')[_0x293bd7(0x2eb)](0xc8), document[_0x293bd7(0x207)]('message')['contentEditable'] = !![], $(_0x293bd7(0x2a3))[0x0][_0x293bd7(0x25e)]();
                    }, 0x32);
                }
            },
            'failure': function(_0x27d6de) {},
            'error': function(_0x4fab82) {}
        });
    }, 0x7d0);
}

function ClAxPtAi(_0x4473e3, _0x4546cf, _0x19e2bd, _0x416831, _0x3035a3 = '') {
    var _0x9c419f = _0xb72139,
        _0x3fc098, _0x1b9f90 = isVoicemute,
        _0x4ea73c = {
            'apiKey': _0x4546cf,
            'salt': _0x19e2bd,
            'SearchText': _0x416831
        };
    return $[_0x9c419f(0x1d3)]({
        'type': _0x9c419f(0x2ea),
        'url': _0x4473e3,
        'data': JSON[_0x9c419f(0x243)](_0x4ea73c),
        'contentType': 'application/json;\x20charset=utf-8',
        'dataType': _0x9c419f(0x28d),
        'async': ![],
        'success': function(_0x44aa4e) {
            var _0x38694f = _0x9c419f;
            try {
                var _0x4995d2 = Object[_0x38694f(0x226)](_0x44aa4e)[0x0],
                    _0x3e758c = JSON['parse'](JSON['stringify'](_0x44aa4e[_0x4995d2]));
                if (_0x3e758c[_0x38694f(0x2ca)] > 0x0) {
                    isVoicemute = !![];
                    var _0x1fb877 = CreateTableFromJSON(_0x3e758c, _searchType);
                    if (_0x1fb877[_0x38694f(0x2ca)] > 0x0) _0x3fc098 = _0x3035a3 ? ['' + _0x1fb877, '' + _0x3035a3] : ['' + _0x1fb877];
                    else _0x3fc098 = ['' + _0x3e758c[0x1][_0x38694f(0x24b)]];
                    invalidSearchCount = 0x0;
                    if (_searchType == 0x2) $(_0x38694f(0x2f4))[_0x38694f(0x2eb)](0x1f4);
                    document[_0x38694f(0x207)](_0x38694f(0x283))[_0x38694f(0x295)] = !![];
                } else {
                    if (!lang_Hindi) _0x3fc098 = [_0x38694f(0x23f), '' + _helplineMsg];
                    else _0x3fc098 = [_0x38694f(0x26f), _0x38694f(0x2bd)];
                    $(_0x38694f(0x2f4))['hide'](0x1f4), document[_0x38694f(0x207)](_0x38694f(0x283))[_0x38694f(0x295)] = !![];
                }
            } catch (_0x44d299) {
                if (!lang_Hindi) _0x3fc098 = [_0x38694f(0x23f), '' + _helplineMsg];
                else _0x3fc098 = ['मैं\x20आपके\x20द्वारा\x20पूछे\x20गए\x20प्रश्न\x20को\x20समझ\x20नहीं\x20पा\x20रही\x20हूँ\x20।', 'कृपया\x20पुन:\x20प्रयास\x20करें\x20।'];
                $(_0x38694f(0x2f4))[_0x38694f(0x2eb)](0x1f4), document[_0x38694f(0x207)]('message')[_0x38694f(0x295)] = !![];
            }
        },
        'failure': function(_0x4a7d2e) {
            var _0x4111d4 = _0x9c419f;
            $(_0x4111d4(0x2f4))[_0x4111d4(0x2eb)](0x1f4), document[_0x4111d4(0x207)](_0x4111d4(0x283))[_0x4111d4(0x295)] = !![];
        },
        'error': function(_0x20367d) {
            var _0x3de45d = _0x9c419f;
            $(_0x3de45d(0x2f4))[_0x3de45d(0x2eb)](0x1f4), document['getElementById'](_0x3de45d(0x283))['contentEditable'] = !![];
        }
    }), setTimeout(function() {
        isVoicemute = _0x1b9f90;
    }, 0x7d0), _0x3fc098;
}

function CreateTableFromJSON(_0x298e95, _0x315585) {
    var _0x2d62c4 = _0xb72139,
        _0x96ec5c, _0x53cc6d = '',
        _0x1d7ccb = typeof _0x298e95 === _0x2d62c4(0x2c4) ? _0x298e95 : JSON[_0x2d62c4(0x32d)](_0x298e95),
        _0x1d3073 = ![];
    try {
        if (_0x315585 == 0x2) _0x1d7ccb[_0x2d62c4(0x2ca)] > 0x0 && (_0x96ec5c = _0x1d7ccb[0x0], _0x1d3073 = !![]);
        else _0x315585 == 0x3 && (_0x1d7ccb['length'] > 0x0 && (_0x96ec5c = _0x1d7ccb[0x0], _0x1d3073 = !![]));
        if (_0x1d3073) {
            if (_0x96ec5c !== null && typeof _0x96ec5c === _0x2d62c4(0x2c4)) {
                _0x53cc6d = '<ul\x20style=\x22list-style-type:none;display:\x20contents\x20!important;\x22>';
                for (var _0x133b0 in _0x96ec5c) {
                    if (_0x96ec5c['hasOwnProperty'](_0x133b0)) {
                        var _0x3d86bc = _0x96ec5c[_0x133b0];
                        _0x53cc6d += _0x2d62c4(0x1fa) + _0x133b0 + _0x2d62c4(0x2f1) + _0x3d86bc + _0x2d62c4(0x204);
                    }
                }
                _0x53cc6d += _0x2d62c4(0x32b);
            } else isJsonString(_0x96ec5c) && (_0x53cc6d = _0x96ec5c);
        } else _0x53cc6d = '';
    } catch (_0x1b23d5) {
        _0x53cc6d = _0x1b23d5[_0x2d62c4(0x283)];
    }
    return _0x53cc6d;
}

function isJsonString(_0x61a585) {
    var _0x5b76a0 = _0xb72139;
    try {
        JSON[_0x5b76a0(0x32d)](_0x61a585);
    } catch (_0x8f167c) {
        return !![];
    }
    return ![];
}

function ClAxGtAi(_0x220a21, _0x593f8a, _0x69607, _0x283331) {}

function setSearchSlider(_0x1d29a8) {
    var _0x27a66e = _0xb72139;
    if ((_searchType == '2' || _searchType == '3') && _searchSuggestion[_0x27a66e(0x2b1)]()[_0x27a66e(0x2ca)] > 0x0) {
        if (_0x1d29a8) $(_0x27a66e(0x23e))[_0x27a66e(0x28a)](_searchSuggestionH);
        else $(_0x27a66e(0x23e))[_0x27a66e(0x28a)](_searchSuggestion);
        setTimeout(function() {
            var _0x30227b = _0x27a66e;
            $(_0x30227b(0x1c6))[_0x30227b(0x26c)](), $(_0x30227b(0x23e))[_0x30227b(0x304)](_0x30227b(0x2a8), function() {
                setTimeout(function() {
                    var _0x418ed8 = _0x4a3a;
                    $(_0x418ed8(0x23e))[_0x418ed8(0x1d6)](_0x418ed8(0x2a8)), $(_0x418ed8(0x1c6))[_0x418ed8(0x1f6)](_0x418ed8(0x247));
                }, 0x1770);
            });
        }, 0x1f40);
    }
}