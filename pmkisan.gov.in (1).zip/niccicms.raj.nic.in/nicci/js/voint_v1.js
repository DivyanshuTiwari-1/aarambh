var _0x88db = ["\x23\x6D\x65\x73\x73\x61\x67\x65", "\x23\x73\x74\x61\x72\x74\x2D\x72\x65\x63\x6F\x72\x64\x2D\x62\x74\x6E", "\x53\x70\x65\x65\x63\x68\x52\x65\x63\x6F\x67\x6E\x69\x74\x69\x6F\x6E", "\x77\x65\x62\x6B\x69\x74\x53\x70\x65\x65\x63\x68\x52\x65\x63\x6F\x67\x6E\x69\x74\x69\x6F\x6E", "\x65\x72\x72\x6F\x72", "\x64\x69\x73\x70\x6C\x61\x79", "\x6E\x6F\x6E\x65", "\x63\x73\x73", "\x63\x6F\x6E\x74\x69\x6E\x75\x6F\x75\x73", "\x6C\x61\x6E\x67", "\x65\x6E\x2D\x55\x53", "\x6F\x6E\x72\x65\x73\x75\x6C\x74", "\x72\x65\x73\x75\x6C\x74\x49\x6E\x64\x65\x78", "\x74\x72\x61\x6E\x73\x63\x72\x69\x70\x74", "\x72\x65\x73\x75\x6C\x74\x73", "", "\x74\x65\x78\x74", "\x63\x6F\x6C\x6F\x72", "\x23\x34\x62\x35\x33\x35\x61", "\x6F\x6E\x73\x74\x61\x72\x74", "\x72\x65\x64", "\x6F\x6E\x73\x70\x65\x65\x63\x68\x65\x6E\x64", "\x6F\x6E\x65\x72\x72\x6F\x72", "\x6E\x6F\x2D\x73\x70\x65\x65\x63\x68", "\x6C\x65\x6E\x67\x74\x68", "\x20", "\x73\x74\x61\x72\x74", "\x73\x74\x61\x74\x65", "\x6C\x6F\x67", "\x6F\x6E\x63\x68\x61\x6E\x67\x65", "\x50\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x20\x63\x68\x61\x6E\x67\x65\x64\x20\x74\x6F\x20", "\x74\x68\x65\x6E", "\x6D\x69\x63\x72\x6F\x70\x68\x6F\x6E\x65", "\x71\x75\x65\x72\x79", "\x70\x65\x72\x6D\x69\x73\x73\x69\x6F\x6E\x73"];
var noteTextarea = $(_0x88db[0]);
var nicci_mic = $(_0x88db[1]);
try {
    var SpeechRecognition = window[_0x88db[2]] || window[_0x88db[3]];
    recognition = new SpeechRecognition()
} catch (e) {
    console[_0x88db[4]](e);
    nicci_mic[_0x88db[7]](_0x88db[5], _0x88db[6])
};
recognition[_0x88db[8]] = false;
recognition[_0x88db[9]] = _0x88db[10];
recognition[_0x88db[11]] = function(_0x8c8dx4) {
    var _0x8c8dx5 = _0x8c8dx4[_0x88db[12]];
    var _0x8c8dx6 = _0x8c8dx4[_0x88db[14]][_0x8c8dx5][0][_0x88db[13]];
    var _0x8c8dx7 = (_0x8c8dx5 == 1 && _0x8c8dx6 == _0x8c8dx4[_0x88db[14]][0][0][_0x88db[13]]);
    if (!_0x8c8dx7) {
        noteContent = _0x88db[15];
        noteContent += _0x8c8dx6;
        noteTextarea[_0x88db[16]](noteContent);
        nicci_mic[_0x88db[7]](_0x88db[17], _0x88db[18])
    }
};
recognition[_0x88db[19]] = function() {
    nicci_mic[_0x88db[7]](_0x88db[17], _0x88db[20])
};
recognition[_0x88db[21]] = function() {
    nicci_mic[_0x88db[7]](_0x88db[17], _0x88db[18])
};
recognition[_0x88db[22]] = function(_0x8c8dx4) {
    if (_0x8c8dx4[_0x88db[4]] == _0x88db[23]) {
        nicci_mic[_0x88db[7]](_0x88db[17], _0x88db[18])
    }
};
startListen = function() {
    if (noteContent[_0x88db[24]]) {
        noteContent += _0x88db[25]
    };
    recognition[_0x88db[26]]();
    return false
};
navigator[_0x88db[34]][_0x88db[33]]({
    name: _0x88db[32]
})[_0x88db[31]](function(_0x8c8dx8) {
    console[_0x88db[28]](_0x8c8dx8[_0x88db[27]]);
    _0x8c8dx8[_0x88db[29]] = function() {
        console[_0x88db[28]](_0x88db[30] + this[_0x88db[27]])
    }
})